"""Пробный период: один раз каждому пользователю (в том числе тем, кто пользовался ботом раньше)."""
from __future__ import annotations

import logging

from services.subscriptions import extend_tx
from utils import clock, texts

log = logging.getLogger(__name__)


class TrialService:
    def __init__(self, db, vpn, notifier, subcard, days: int = 1):
        self.db, self.vpn, self.notifier, self.subcard, self.days = db, vpn, notifier, subcard, days

    async def grant(self, user: dict) -> bool:
        """Выдаёт пробный период, если он ещё не выдавался и у пользователя никогда не было подписки.
        Возвращает True, если подписка создана сейчас. Повторные/параллельные вызовы безопасны."""
        if self.days <= 0 or user.get("trial_granted_at"):
            return False
        now = clock.now()
        async with self.db.tx() as t:
            row = await t.fetchone("SELECT trial_granted_at FROM users WHERE id=?", (user["id"],))
            if not row or row["trial_granted_at"]:
                return False
            await t.execute("UPDATE users SET trial_granted_at=? WHERE id=?", (now, user["id"]))
            had = await t.fetchone("SELECT 1 FROM subscriptions WHERE user_id=?", (user["id"],))
            if had:
                return False                      # уже был доступ — пробный не нужен, но отметили, чтобы не проверять снова
            await extend_tx(t, user["id"], self.days, plan_id="trial", now=now)
        user["trial_granted_at"] = now
        res = await self.vpn.sync_user(user["id"])
        if not res.ok:
            log.warning("trial: панель не ответила для user %s: %s", user["id"], res.errors)
        return True

    async def notify(self, user: dict) -> None:
        text, markup = await self.subcard.render(
            user, note=f"🎁 Вам выдан пробный период на {texts.fmt_days(self.days)}!")
        await self.notifier.once(user, "TRIAL", "granted", text, markup)
