"""Карточка «Моя подписка» (одна и та же в «Мои подключения», после оплаты и при выдаче пробного периода)."""
from __future__ import annotations

from utils import texts

E = texts.E
FALLBACK_LIMIT = 3000      # столько символов ключей помещаем в одно сообщение


class SubCard:
    def __init__(self, db, subs, plans, vpn, users, settings, keyboards=None):
        self.db, self.subs, self.plans, self.vpn, self.users = db, subs, plans, vpn, users
        self.settings = settings
        self._kb = keyboards

    @property
    def kb(self):
        if self._kb is None:
            import keyboards as _k
            self._kb = _k
        return self._kb

    async def sub_url(self, user: dict) -> str | None:
        """Короткая ссылка-подписка: сначала подписка самой панели, затем лента бота (PUBLIC_URL)."""
        s = self.settings
        if not (s.xui_sub_url or s.public_url):
            return None
        token = await self.users.sub_token(user["id"])
        if s.xui_sub_url:
            return f"{s.xui_sub_url}/{token}"
        return f"{s.public_url}/sub/{token}"

    async def render(self, user: dict, *, note: str | None = None):
        """→ (текст, клавиатура)."""
        sub = await self.subs.view(user["id"])
        if not sub or not sub["is_active"]:
            return ("📊 <b>Моя подписка</b>\n\nУ вас нет активной подписки.", self.kb.no_sub_kb())
        plan = await self.plans.get(sub["plan_id"]) if sub["plan_id"] else None
        tz = self.settings.timezone
        lines = ["📊 <b>Моя подписка</b>", "",
                 f"🗓 Тариф: <b>{E(plan['name']) if plan else 'Бонусные дни'}</b>",
                 f"⏳ Осталось: <b>{E(texts.fmt_remaining(sub['remaining']))}</b>",
                 f"📅 Действует до: <b>{texts.fmt_dt(sub['ends_at'], tz)}</b>"]
        if note:
            lines += ["", note]
        url = await self.sub_url(user)
        views = [v for v in await self.vpn.connections(user["id"]) if v.link]
        if url:
            lines += ["", "🔑 Ваша ссылка для подключения:", f"<code>{E(url)}</code>"]
            if any(v.is_placeholder for v in views):
                lines += ["", "🧪 <i>Тестовый режим: в подписке заглушки вместо серверов.</i>"]
            return "\n".join(lines), self.kb.sub_card_kb(url, show_all=False)
        if not views:
            lines += ["", "🔑 Подключения готовятся — обычно это занимает меньше минуты."]
            return "\n".join(lines), self.kb.sub_card_kb(None, show_all=False, refresh=True)
        body = "\n".join(v.link for v in views)
        if len(body) <= FALLBACK_LIMIT:
            lines += ["", "🔑 Ваши ключи (нажмите на блок, чтобы скопировать):", f"<code>{E(body)}</code>"]
            show_all = False
        else:
            lines += ["", "🔑 Ключей много — откройте «Все ссылки»."]
            show_all = True
        if any(v.is_placeholder for v in views):
            lines += ["", "🧪 <i>Тестовый режим: это заглушки, а не рабочие конфигурации.</i>"]
        return "\n".join(lines), self.kb.sub_card_kb(None, show_all=show_all)
