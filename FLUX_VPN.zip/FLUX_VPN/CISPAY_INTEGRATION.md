# cisPay integration in FLUX VPN — polling only

Official API schema: https://api.cispay.app/openapi.json

## No webhook, domain, tunnel, or public URL required

FLUX VPN confirms cisPay payments only by making authenticated API requests from the bot VPS. It does not register a cisPay webhook, expose a payment callback route, or require a public domain/HTTPS endpoint for payment confirmation.

## Credentials

Get `Shop ID` (UUID) and `API Key` (`cis_sec_...`) from cisPay Merchant Dashboard → Store Settings. Keep the API key private.

Add to `.env`:

```dotenv
CISPAY_SHOP_ID=your-shop-uuid
CISPAY_API_KEY=cis_sec_your_secret_key
CISPAY_ALLOW_SANDBOX=false
ORDER_TTL_CISPAY_MIN=60
```

## Checkout

FLUX creates hosted checkout using `POST https://api.cispay.app/payments` with required headers `X-Shop-ID` and `X-Api-Key`. The request includes:

- `amount`: whole RUB order amount multiplied by 100 (kopecks);
- `currency`: `RUB`;
- `order_id`: unique FLUX public order ID;
- `customer_id`: Telegram user ID (required when payment method is omitted);
- `description` and `payload`: order information.

No `payment_method` is forced, so the customer can choose among the methods enabled for the cisPay store. The bot saves the cisPay transaction UUID and sends the customer to `payment_url`.

## Automatic status polling

Every 10 seconds the background scheduler checks each pending cisPay order with authenticated `GET /payments/status?id=<cisPay transaction UUID>`. If the external transaction ID is not yet stored, it falls back to `order_id=<FLUX public order ID>`.

A VPN subscription is activated only when the authenticated status response reports `PAID` and all checks pass:

- response `order_id` matches the local order;
- response `payload`, when present, matches the local order;
- transaction `id` matches the saved cisPay transaction UUID;
- currency is RUB;
- `amount` exactly matches the expected amount in kopecks;
- `charged_amount` is not below the expected amount;
- sandbox payments are rejected unless `CISPAY_ALLOW_SANDBOX=true`.

`FAILED` and `EXPIRED` statuses cancel the pending local order. Repeated status checks are safe: FLUX uses its existing transactional, idempotent payment fulfillment pipeline, so a paid order cannot grant the subscription twice.

## Telegram Stars

Stars remain native Telegram payments and do not use cisPay. Set the Stars price for each tariff in Admin → Settings → Tariffs. Only cisPay and Stars are registered as active payment providers. Legacy CryptoBot/DonateAlerts modules and historical database rows are retained in source/database for backwards compatibility, but are not exposed at runtime.

## Optional public URL

`PUBLIC_URL` is unrelated to cisPay. It is optional and is used only if FLUX should expose its own `/sub/<token>` VPN subscription feed. Payment creation and payment confirmation work without it.
