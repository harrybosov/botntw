"""cisPay Merchant API integration using status polling only (no webhook)."""
from __future__ import annotations

import logging

from models import CURRENCY_RUB, OrderStatus, Provider
from payments.base import PaymentProvider, PaymentStart
from utils.http import HttpClient

log = logging.getLogger(__name__)
API_BASE = "https://api.cispay.app"


class CisPayProvider(PaymentProvider):
    code = Provider.CISPAY
    title = "💳 cisPay"

    def __init__(self, shop_id: str, api_key: str, orders, users, fulfillment,
                 allow_sandbox: bool = False, http=None):
        self.shop_id = shop_id
        self.api_key = api_key
        self.orders = orders
        self.users = users
        self.fulfillment = fulfillment
        self.allow_sandbox = allow_sandbox
        self.http = http or HttpClient(timeout=25)

    def is_configured(self) -> bool:
        return bool(self.shop_id and self.api_key)

    def _headers(self) -> dict:
        # cisPay requires both headers on every merchant API request.
        return {
            "X-Shop-ID": self.shop_id,
            "X-Api-Key": self.api_key,
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    async def start(self, order: dict, user: dict) -> PaymentStart:
        # Reuse an already-created invoice when the user returns to the same pending order.
        # cisPay rejects a second POST /payments with the same merchant order_id.
        if order.get("external_id") and order.get("pay_url"):
            return PaymentStart(
                text=(f"💳 Счёт cisPay на <b>{order['amount']} ₽</b> уже создан.\n"
                      "Откройте ссылку и завершите оплату. Бот проверит её автоматически."),
                url=order["pay_url"], external_id=str(order["external_id"]), show_check=True,
            )
        # cisPay expects RUB minor units (kopecks); FLUX stores whole RUB.
        amount_kopecks = int(order["amount"]) * 100
        payload = {
            "amount": amount_kopecks,
            "currency": "RUB",
            "order_id": order["public_id"],
            # customer_id is required by cisPay when payment_method is omitted,
            # allowing the customer to choose among the store's enabled methods.
            "customer_id": str(user["tg_id"])[:40],
            "description": f"FLUX VPN — {order['plan_name']} ({order['days']} дн.)"[:512],
            "payload": order["public_id"],
        }
        status, body, raw = await self.http.request(
            "POST", f"{API_BASE}/payments", headers=self._headers(), json_body=payload)
        if status != 201 or not isinstance(body, dict):
            detail = body.get("detail") if isinstance(body, dict) else raw
            raise RuntimeError(f"cisPay API error HTTP {status}: {str(detail or raw)[:500]}")

        payment_id = body.get("id")
        payment_url = body.get("payment_url")
        if not payment_id or not payment_url or body.get("order_id") != order["public_id"]:
            raise RuntimeError("cisPay returned an incomplete or mismatched payment response")
        if body.get("status") != "PENDING":
            raise RuntimeError(f"cisPay returned unexpected initial status: {body.get('status')}")
        if int(body.get("amount", -1)) != amount_kopecks:
            raise RuntimeError("cisPay returned an unexpected payment amount")
        return PaymentStart(
            text=(f"💳 Счёт создан в cisPay на <b>{order['amount']} ₽</b>.\n"
                  "Нажмите кнопку ниже и завершите оплату. Бот проверит платёж автоматически "
                  "и активирует подписку после подтверждения cisPay."),
            url=payment_url,
            external_id=str(payment_id),
            show_check=True,
        )

    async def _fulfill_paid_status(self, order: dict, data: dict) -> bool:
        """Validate an authenticated status response and pass it to idempotent fulfillment."""
        if not isinstance(data, dict) or data.get("status") != "PAID":
            return False
        if str(data.get("order_id", "")) != str(order["public_id"]):
            log.warning("cisPay order_id mismatch for local order=%s", order["public_id"])
            return False
        # payload is our second independent order reference; if returned, it must match.
        if data.get("payload") not in (None, "", order["public_id"]):
            log.warning("cisPay payload mismatch for local order=%s", order["public_id"])
            return False
        transaction_id = str(data.get("id") or "")
        if not transaction_id:
            log.warning("cisPay status response has no transaction id for order=%s", order["public_id"])
            return False
        if order.get("external_id") and transaction_id != str(order["external_id"]):
            log.warning("cisPay transaction id mismatch for order=%s", order["public_id"])
            return False
        if str(data.get("currency", "RUB")).upper() != "RUB":
            log.warning("cisPay currency mismatch for order=%s", order["public_id"])
            return False
        try:
            amount = int(data.get("amount"))
            charged_amount = int(data.get("charged_amount", amount))
        except (TypeError, ValueError):
            log.warning("cisPay invalid amount for order=%s", order["public_id"])
            return False
        expected = int(order["amount"]) * 100
        if amount != expected or charged_amount < expected:
            log.warning("cisPay amount mismatch order=%s amount=%s charged=%s expected=%s",
                        order["public_id"], amount, charged_amount, expected)
            return False
        if data.get("is_sandbox") and not self.allow_sandbox:
            log.warning("cisPay sandbox payment ignored for order=%s", order["public_id"])
            return False

        outcome = await self.fulfillment.confirm(
            order["id"], source=Provider.CISPAY, external_id=transaction_id,
            amount=int(order["amount"]), currency=CURRENCY_RUB,
            note=(f"cisPay payment_method={data.get('payment_method') or 'unknown'}; "
                  f"sandbox={bool(data.get('is_sandbox'))}"),
        )
        return outcome.status in ("ok", "duplicate")

    async def check(self, order: dict) -> bool:
        """Ask cisPay directly; no browser redirect or callback is trusted as payment proof."""
        if order.get("status") != OrderStatus.PENDING:
            return order.get("status") == OrderStatus.PAID
        if order.get("provider") != Provider.CISPAY:
            return False

        # OpenAPI accepts either id (cisPay transaction UUID) or our order_id.
        params = {"id": str(order["external_id"])} if order.get("external_id") else {
            "order_id": order["public_id"]
        }
        status, body, raw = await self.http.request(
            "GET", f"{API_BASE}/payments/status", headers=self._headers(), params=params)
        if status != 200 or not isinstance(body, dict):
            log.warning("cisPay status check failed HTTP %s for order=%s: %s",
                        status, order["public_id"], str(raw)[:300])
            return False
        if body.get("status") == "PAID":
            return await self._fulfill_paid_status(order, body)
        if body.get("status") in ("FAILED", "EXPIRED"):
            await self.orders.cancel(order["id"])
        elif body.get("status") == "REFUNDED":
            log.warning("cisPay reports REFUNDED for still-pending local order=%s", order["public_id"])
        return False

    async def poll_pending(self) -> None:
        """Background status polling. Scheduler invokes this every 10 seconds."""
        for order in await self.orders.pending_by_provider(Provider.CISPAY):
            try:
                await self.check(order)
            except Exception:  # noqa: BLE001
                log.exception("cisPay polling failed for order=%s", order["public_id"])
