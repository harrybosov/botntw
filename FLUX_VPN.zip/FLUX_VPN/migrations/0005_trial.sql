-- Пробный период: выдаётся каждому пользователю один раз.
ALTER TABLE users ADD COLUMN trial_granted_at INTEGER;
INSERT OR IGNORE INTO plans (id, name, days, price_rub, is_active, sort_order, created_at, updated_at)
VALUES ('trial', '1 день (пробный)', 1, 1, 0, 0, strftime('%s','now'), strftime('%s','now'));
