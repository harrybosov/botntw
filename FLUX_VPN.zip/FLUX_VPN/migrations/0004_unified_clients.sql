-- Один клиент панели может быть привязан к нескольким inbound: email больше не уникален в vpn_clients.
CREATE TABLE vpn_clients_new (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    inbound_id  INTEGER NOT NULL REFERENCES vpn_inbounds(id) ON DELETE CASCADE,
    email       TEXT NOT NULL,
    secret      TEXT NOT NULL,
    expiry_at   INTEGER NOT NULL,
    enabled     INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0,1)),
    synced_at   INTEGER NOT NULL,
    UNIQUE (user_id, inbound_id)
);
INSERT INTO vpn_clients_new(id,user_id,inbound_id,email,secret,expiry_at,enabled,synced_at)
    SELECT id,user_id,inbound_id,email,secret,expiry_at,enabled,synced_at FROM vpn_clients;
DROP TABLE vpn_clients;
ALTER TABLE vpn_clients_new RENAME TO vpn_clients;
CREATE INDEX idx_vpn_clients_user ON vpn_clients(user_id);
