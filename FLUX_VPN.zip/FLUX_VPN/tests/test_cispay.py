from payments.cispay import CisPayProvider
from models import Provider
from tests.helpers import BaseCase


class FakeHttp:
    def __init__(self):
        self.calls = []
        self.responses = []

    async def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        return self.responses.pop(0)


class CisPayTests(BaseCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.http = FakeHttp()
        self.user = await self.new_user(808)
        self.order = await self.env.orders.create_order(self.user["id"], "m1", Provider.CISPAY)
        self.provider = CisPayProvider("shop-uuid", "cis_sec_test", self.env.orders, self.env.users,
                                       self.env.fulfillment, http=self.http)

    def paid_status(self, **overrides):
        data = {
            "id": "transaction-1",
            "order_id": self.order["public_id"],
            "payload": self.order["public_id"],
            "status": "PAID",
            "amount": self.order["amount"] * 100,
            "charged_amount": self.order["amount"] * 100,
            "currency": "RUB",
            "payment_method": "SBP",
            "is_sandbox": False,
        }
        data.update(overrides)
        return data

    async def test_create_payment_in_kopecks(self):
        self.http.responses.append((201, {
            "id": "uuid-pay", "order_id": self.order["public_id"],
            "amount": self.order["amount"] * 100, "charged_amount": self.order["amount"] * 100,
            "payment_url": "https://checkout.example/pay", "status": "PENDING",
        }, ""))
        start = await self.provider.start(self.order, self.user)
        _, url, kwargs = self.http.calls[0]
        self.assertEqual(url, "https://api.cispay.app/payments")
        self.assertEqual(kwargs["json_body"]["amount"], self.order["amount"] * 100)
        self.assertEqual(kwargs["json_body"]["customer_id"], "808")
        self.assertEqual(kwargs["json_body"]["order_id"], self.order["public_id"])
        self.assertEqual(start.url, "https://checkout.example/pay")
        self.assertEqual(start.external_id, "uuid-pay")

    async def test_status_polling_activates_once(self):
        await self.env.orders.set_external(self.order["id"], "transaction-1", None)
        self.order = await self.env.orders.get(self.order["id"])
        self.http.responses.append((200, self.paid_status(), ""))
        self.assertTrue(await self.provider.check(self.order))
        end = (await self.env.subs.get(self.user["id"]))["ends_at"]
        self.assertEqual((await self.env.orders.get(self.order["id"]))["status"], "PAID")

        # A second check cannot run on a paid order or extend it twice.
        self.assertTrue(await self.provider.check(await self.env.orders.get(self.order["id"])))
        self.assertEqual((await self.env.subs.get(self.user["id"]))["ends_at"], end)

    async def test_wrong_amount_or_order_does_not_activate(self):
        self.http.responses.append((200, self.paid_status(amount=1), ""))
        self.assertFalse(await self.provider.check(self.order))
        self.assertIsNone(await self.env.subs.get(self.user["id"]))

        self.http.responses.append((200, self.paid_status(order_id="OTHER"), ""))
        self.assertFalse(await self.provider.check(self.order))
        self.assertIsNone(await self.env.subs.get(self.user["id"]))

    async def test_sandbox_rejected_by_default(self):
        self.http.responses.append((200, self.paid_status(is_sandbox=True), ""))
        self.assertFalse(await self.provider.check(self.order))
        self.assertIsNone(await self.env.subs.get(self.user["id"]))

    async def test_failed_status_cancels_pending_order(self):
        self.http.responses.append((200, {"id": "transaction-1", "order_id": self.order["public_id"],
                                           "status": "FAILED"}, ""))
        self.assertFalse(await self.provider.check(self.order))
        self.assertEqual((await self.env.orders.get(self.order["id"]))["status"], "CANCELLED")
