import os
import unittest

from config import ConfigError, Settings

KEYS = ["VPN_MODE", "VPN_NODES", "BOT_TOKEN", "ADMIN_IDS"]


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self._old = dict(os.environ)
        for k in list(os.environ):
            if k.startswith(("XUI_", "VPN_")):
                del os.environ[k]

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._old)

    def load(self, **env):
        os.environ.update(env)
        return Settings.load(env_file="/nonexistent")

    def test_one_shared_panel_for_both_countries(self):
        s = self.load(VPN_MODE="xui", XUI_URL="https://1.2.3.4:2053/path/", XUI_USERNAME="u", XUI_PASSWORD="p")
        de, us = s.nodes
        self.assertEqual((de.key, us.key), ("DE", "US"))
        self.assertEqual(de.base_url, "https://1.2.3.4:2053/path")       # завершающий / убран
        self.assertEqual((us.username, us.password), ("u", "p"))
        self.assertEqual(de.public_host, "1.2.3.4")                        # хост берётся из URL
        self.assertEqual(de.inbound_ids, [1, 2, 3])
        self.assertEqual(us.inbound_ids, [4, 5, 6])                        # та же панель → следующие ID
        self.assertFalse(de.verify_ssl)                                    # адрес-IP → самоподписанный

    def test_domain_panel_verifies_ssl_by_default(self):
        s = self.load(VPN_MODE="xui", XUI_URL="https://panel.example.org/p", XUI_USERNAME="u", XUI_PASSWORD="p")
        self.assertTrue(s.nodes[0].verify_ssl)
        self.assertEqual(s.nodes[0].public_host, "panel.example.org")

    def test_explicit_values_and_second_panel_override(self):
        s = self.load(VPN_MODE="xui", XUI_URL="https://1.1.1.1:1/a", XUI_USERNAME="u", XUI_PASSWORD="p",
                      XUI_DE_INBOUNDS="7,8,9", XUI_US_URL="https://2.2.2.2:2/b", XUI_US_USERNAME="u2",
                      XUI_US_PASSWORD="p2", XUI_VERIFY_SSL="true", XUI_US_HOST="us.example.org")
        de, us = s.nodes
        self.assertEqual(de.inbound_ids, [7, 8, 9])
        self.assertEqual((us.base_url, us.username, us.public_host), ("https://2.2.2.2:2/b", "u2", "us.example.org"))
        self.assertEqual(us.inbound_ids, [1, 2, 3])                        # другая панель → с начала
        self.assertTrue(de.verify_ssl and us.verify_ssl)

    def test_old_per_node_variables_still_work(self):
        s = self.load(VPN_MODE="xui", XUI_DE_URL="https://de/x", XUI_DE_USERNAME="a", XUI_DE_PASSWORD="b",
                      XUI_DE_HOST="de.host", XUI_US_URL="https://us/y", XUI_US_USERNAME="c",
                      XUI_US_PASSWORD="d", XUI_US_HOST="us.host")
        self.assertEqual([n.public_host for n in s.nodes], ["de.host", "us.host"])

    def test_missing_credentials_give_clear_error_but_token_is_enough(self):
        with self.assertRaises(ConfigError) as cm:
            self.load(VPN_MODE="xui", XUI_URL="https://1.2.3.4/p")
        self.assertIn("XUI_USERNAME", str(cm.exception))
        s = self.load(VPN_MODE="xui", XUI_URL="https://1.2.3.4/p", XUI_API_TOKEN="tok")
        self.assertEqual(s.nodes[0].api_token, "tok")

    def test_malformed_urls_are_cleaned(self):
        s = self.load(VPN_MODE="xui", XUI_URL="https:https://s-1.example.shop/AbC/", XUI_USERNAME="u",
                      XUI_PASSWORD="p", XUI_SUB_URL="panel.example.org:2096/sub/")
        self.assertEqual(s.nodes[0].base_url, "https://s-1.example.shop/AbC")
        self.assertEqual(s.nodes[0].public_host, "s-1.example.shop")
        self.assertEqual(s.xui_sub_url, "https://panel.example.org:2096/sub")

    def test_channel_and_trial_settings(self):
        s = self.load(VPN_MODE="mock")
        self.assertEqual((s.required_channel, s.trial_days), ("@flux_vpnofficial", 1))
        s = self.load(VPN_MODE="mock", REQUIRED_CHANNEL="", TRIAL_DAYS="2")
        self.assertEqual((s.required_channel, s.trial_days), ("", 2))

    def test_mock_mode_needs_nothing(self):
        s = self.load(VPN_MODE="mock")
        self.assertEqual(len(s.nodes), 2)
        self.assertIn("tok", Settings.load(env_file="/nonexistent").secrets() + ["tok"])
