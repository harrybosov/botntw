"""Панель 3.x: ОДИН клиент на пользователя, привязанный ко всем 6 inbound'ам (две «страны» на одной панели).
Пробный период и карточка «Моя подписка»."""
import base64
from types import SimpleNamespace

from tests.helpers import DAY, T0, BaseCase, FakeKb, FakePanel, reality_inbound
from services.subcard import SubCard
from utils import clock
from vpn.nodes import NodeRegistry
from vpn.subscriptions import VpnManager, client_email, shared_email
from vpn.xui_adapter import XuiAdapter

BASE = "https://panel.test/secret"
NODE = SimpleNamespace(key="DE", base_url=BASE, username="admin", password="pw", public_host="de.test",
                       verify_ssl=True, country="DE", inbound_ids=[7, 8, 9])


def make_world(env):
    """Одна панель 3.x с inbound'ами 7,8,9 (Германия) и 1,2,3 (США); один адаптер на обе страны."""
    panel = FakePanel(BASE, {i: reality_inbound(i) for i in (1, 2, 3, 7, 8, 9)})
    panel.modern = True
    panel.require_csrf = True
    adapter = XuiAdapter(NODE, transport=panel)
    nodes = [SimpleNamespace(key="DE", country="DE", public_host="de.test", inbound_ids=[7, 8, 9]),
             SimpleNamespace(key="US", country="US", public_host="de.test", inbound_ids=[1, 2, 3])]
    registry = NodeRegistry(env.db, nodes, {"DE": adapter, "US": adapter})
    return panel, registry


class UnifiedClientTests(BaseCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.panel, registry = make_world(self.env)
        await registry.sync_db()
        self.env.registry = registry
        self.env.vpn = VpnManager(self.env.db, registry)
        self.env.fulfillment.vpn = self.env.vpn
        self.env.trial.vpn = self.env.vpn
        self.env.subcard.vpn = self.env.vpn

    async def test_one_client_attached_to_all_six_inbounds(self):
        u = await self.new_user(2062107453)
        _, out = await self.paid_order(u)
        self.assertEqual(out.status, "ok")
        self.assertEqual(list(self.panel.mclients), ["flux2062107453"])          # ОДИН клиент, не шесть
        c = self.panel.mclients["flux2062107453"]
        self.assertEqual(sorted(c["inbounds"]), [1, 2, 3, 7, 8, 9])
        self.assertEqual(c["client"]["subId"], await self.env.users.sub_token(u["id"]))
        self.assertEqual(c["client"]["expiryTime"], (T0 + 30 * DAY) * 1000)
        self.assertEqual((await self.env.subs.get(u["id"]))["vpn_dirty"], 0)
        self.assertEqual(await self.env.vpn.count_clients(u["id"]), 6)

    async def test_repeat_sync_and_renewal_do_not_duplicate(self):
        u = await self.new_user()
        await self.paid_order(u, ext="a")
        for _ in range(3):
            self.assertTrue((await self.env.vpn.sync_user(u["id"])).ok)
        await self.paid_order(u, "m3", ext="b")
        self.assertEqual(len(self.panel.mclients), 1)
        email = shared_email(u["tg_id"])
        self.assertEqual(self.panel.mclients[email]["client"]["expiryTime"], (T0 + 120 * DAY) * 1000)

    async def test_old_per_server_clients_are_cleaned_up_and_subid_conflict_resolved(self):
        """Как у вас в панели: остались flux<ID>-us1 / -de1 с тем же subId → раньше «subId already in use»."""
        u = await self.new_user(2062107453)
        token = await self.env.users.sub_token(u["id"])
        for email in (client_email(u["tg_id"], "US", 1), client_email(u["tg_id"], "DE", 1)):
            self.panel.mclients[email] = {"client": {"email": email, "subId": token, "uuid": "old"}, "inbounds": [1]}
        self.panel.mclients["harry"] = {"client": {"email": "harry", "subId": "HARRYSUB", "uuid": "h"},
                                        "inbounds": [1, 2, 3, 7, 8, 9]}
        _, out = await self.paid_order(u)
        self.assertEqual(out.status, "ok")
        self.assertEqual(sorted(self.panel.mclients), ["flux2062107453", "harry"])    # чужой клиент не тронут
        self.assertEqual(sorted(self.panel.mclients["flux2062107453"]["inbounds"]), [1, 2, 3, 7, 8, 9])

    async def test_partial_attachment_is_completed(self):
        """Клиент уже есть, но привязан только к одному inbound (как «только Германия») — докрепляем остальные."""
        u = await self.new_user(77)
        token = await self.env.users.sub_token(u["id"])
        self.panel.mclients["flux77"] = {"client": {"email": "flux77", "subId": token, "uuid": "u1",
                                                    "enable": True, "expiryTime": 1}, "inbounds": [7]}
        await self.paid_order(u)
        self.assertEqual(sorted(self.panel.mclients["flux77"]["inbounds"]), [1, 2, 3, 7, 8, 9])

    async def test_connections_come_from_panel_links(self):
        u = await self.new_user()
        await self.paid_order(u)
        views = await self.env.vpn.connections(u["id"])
        self.assertEqual(len(views), 6)
        self.assertTrue(all(v.link.startswith("vless://") and "@de.test:443" in v.link for v in views))
        self.assertEqual(len({v.link for v in views}), 6)

    async def test_expiry_disables_the_single_client(self):
        u = await self.new_user()
        await self.paid_order(u, "test")
        clock.advance(8 * DAY)
        sub = (await self.env.subs.due_for_expiry())[0]
        await self.env.subs.mark_expired(sub["id"])
        self.assertTrue((await self.env.vpn.sync_user(u["id"])).ok)
        self.assertFalse(self.panel.mclients[shared_email(u["tg_id"])]["client"]["enable"])

    async def test_panel_failure_keeps_dirty_then_recovers(self):
        u = await self.new_user()
        self.panel.conn_error = True
        _, out = await self.paid_order(u)
        self.assertEqual(out.status, "ok")                    # деньги приняты, подписка записана
        self.assertEqual((await self.env.subs.get(u["id"]))["vpn_dirty"], 1)
        self.panel.conn_error = False
        self.assertTrue((await self.env.vpn.sync_user(u["id"])).ok)
        self.assertEqual(len(self.panel.mclients), 1)


class SubCardTests(BaseCase):
    async def test_card_with_short_panel_link(self):
        u = await self.new_user()
        await self.paid_order(u, "m1")
        self.env.cfg.xui_sub_url = "https://panel.test:2096/sub"
        text, markup = await self.env.subcard.render(u)
        token = await self.env.users.sub_token(u["id"])
        url = f"https://panel.test:2096/sub/{token}"
        self.assertIn("Моя подписка", text)
        self.assertIn("1 месяц", text)
        self.assertIn("Осталось", text)
        self.assertIn(f"<code>{url}</code>", text)                      # ссылка моноширинным — копируется нажатием
        self.assertNotIn("vless://", text)
        self.assertEqual(markup["url"], url)

    async def test_bot_feed_used_when_no_panel_sub(self):
        u = await self.new_user()
        await self.paid_order(u)
        self.env.cfg.public_url = "https://bot.example.org"
        url = await self.env.subcard.sub_url(u)
        self.assertEqual(url, f"https://bot.example.org/sub/{await self.env.users.sub_token(u['id'])}")

    async def test_fallback_lists_all_keys_without_sub_url(self):
        u = await self.new_user()
        await self.paid_order(u)
        text, markup = await self.env.subcard.render(u)
        self.assertEqual(text.count("flux-demo://"), 6)                  # mock: все 6 в одном блоке
        self.assertIsNone(markup["url"])

    async def test_no_subscription_card(self):
        u = await self.new_user()
        text, markup = await self.env.subcard.render(u)
        self.assertIn("нет активной подписки", text)
        self.assertEqual(markup, {"no_sub": True})

    async def test_payment_notification_is_the_card(self):
        u = await self.new_user()
        self.env.cfg.xui_sub_url = "https://panel.test:2096/sub"
        await self.paid_order(u, "m1")
        sent = [t for _, t in self.env.notifier.sent]
        self.assertTrue(any("Оплата получена" in t and "Ваша ссылка для подключения" in t for t in sent))


class TrialTests(BaseCase):
    async def test_new_user_gets_one_day_once(self):
        u = await self.new_user()
        self.assertTrue(await self.env.trial.grant(u))
        sub = await self.env.subs.get(u["id"])
        self.assertEqual((sub["plan_id"], sub["ends_at"]), ("trial", T0 + DAY))
        self.assertEqual(await self.env.vpn.count_clients(u["id"]), 6)         # сразу выдан доступ ко всем серверам
        self.assertFalse(await self.env.trial.grant(u))                        # второй раз — нет
        fresh = await self.env.users.get(u["id"])
        self.assertFalse(await self.env.trial.grant(fresh))
        self.assertEqual((await self.env.subs.get(u["id"]))["ends_at"], T0 + DAY)

    async def test_existing_user_without_subscription_also_gets_trial(self):
        # пользователь зарегистрирован давно (trial_granted_at пуст), но подписки никогда не было
        u = await self.new_user()
        self.assertIsNone(u["trial_granted_at"])
        self.assertTrue(await self.env.trial.grant(u))

    async def test_user_who_already_had_subscription_gets_no_trial(self):
        u = await self.new_user()
        await self.paid_order(u, "m1")
        end = (await self.env.subs.get(u["id"]))["ends_at"]
        fresh = await self.env.users.get(u["id"])
        self.assertFalse(await self.env.trial.grant(fresh))
        self.assertEqual((await self.env.subs.get(u["id"]))["ends_at"], end)

    async def test_trial_is_not_a_payment_and_gives_no_referral_bonus(self):
        ref = await self.new_user(1)
        inv = await self.new_user(2, ref=1)
        await self.env.trial.grant(inv)
        self.assertEqual((await self.env.users.get(ref["id"]))["bonus_days"], 0)
        n = await self.env.db.fetchone("SELECT COUNT(*) c FROM payments")
        self.assertEqual(n["c"], 0)

    async def test_trial_card_notification_sent_once(self):
        u = await self.new_user()
        await self.env.trial.grant(u)
        await self.env.trial.notify(u)
        await self.env.trial.notify(u)
        texts_ = [t for _, t in self.env.notifier.sent if "пробный период" in t]
        self.assertEqual(len(texts_), 1)
        self.assertIn("1 день (пробный)", texts_[0])

    async def test_trial_expires_normally_and_disables_access(self):
        u = await self.new_user()
        await self.env.trial.grant(u)
        clock.advance(2 * DAY)
        sub = (await self.env.subs.due_for_expiry())[0]
        self.assertTrue(await self.env.subs.mark_expired(sub["id"]))
        await self.env.vpn.sync_user(u["id"])
        self.assertEqual(await self.env.vpn.connections(u["id"]), [])

    async def test_trial_plan_hidden_from_shop_and_admin_lists(self):
        self.assertNotIn("trial", [p["id"] for p in await self.env.plans.list_active()])
        self.assertNotIn("trial", [p["id"] for p in await self.env.plans.list_all()])

    async def test_disabled_trial(self):
        self.env.trial.days = 0
        u = await self.new_user()
        self.assertFalse(await self.env.trial.grant(u))
        self.assertIsNone(await self.env.subs.get(u["id"]))


class PanelSubBaseTests(BaseCase):
    def test_sub_base_from_settings(self):
        f = XuiAdapter._sub_base_from_settings
        self.assertEqual(f({"subURI": "https://sub.1-2-3-4.sslip.io/sub/"}, "h"), "https://sub.1-2-3-4.sslip.io/sub")
        self.assertEqual(f({"subPort": 2096, "subPath": "/sub/"}, "panel.host"), "http://panel.host:2096/sub")
        self.assertEqual(f({"subPort": 443, "subPath": "/x/", "subDomain": "d.org", "subCertFile": "/c.pem"}, "h"),
                         "https://d.org/x")
        self.assertIsNone(f({"subEnable": False}, "h"))

    async def test_detect_uses_panel_settings_endpoint(self):
        panel = FakePanel(BASE, {1: reality_inbound(1)})
        orig = panel.request

        async def req(method, url, **kw):
            if url.endswith("/panel/setting/all"):
                if not panel.logged:
                    return 404, None, ""
                return 200, {"success": True, "obj": {"subPort": 2096, "subPath": "/sub/", "subDomain": "s.example.org",
                                                      "subCertFile": "/cert"}}, ""
            return await orig(method, url, **kw)
        panel.request = req
        self.assertEqual(await XuiAdapter(NODE, transport=panel).detect_sub_base(), "https://s.example.org:2096/sub")
