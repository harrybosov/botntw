"""Единая ссылка-подписка: один токен → все 6 серверов."""
import base64

from tests.helpers import DAY, BaseCase
from utils import clock


def decode(body: str) -> list[str]:
    return [x for x in base64.b64decode(body).decode().split("\n") if x]


class FeedTests(BaseCase):
    async def test_token_is_stable_and_unique(self):
        a, b = await self.new_user(1), await self.new_user(2)
        t1 = await self.env.users.sub_token(a["id"])
        self.assertEqual(t1, await self.env.users.sub_token(a["id"]))
        self.assertNotEqual(t1, await self.env.users.sub_token(b["id"]))
        self.assertGreaterEqual(len(t1), 24)

    async def test_feed_contains_all_six_links_and_headers(self):
        u = await self.new_user()
        await self.paid_order(u)
        token = await self.env.users.sub_token(u["id"])
        status, headers, body = await self.env.vpn.feed(token)
        self.assertEqual(status, 200)
        links = decode(body)
        self.assertEqual(len(links), 6)
        self.assertEqual(len(set(links)), 6)
        self.assertIn("expire=", headers["subscription-userinfo"])
        self.assertTrue(headers["profile-title"].startswith("base64:"))

    async def test_unknown_token_and_blocked_user(self):
        self.assertEqual((await self.env.vpn.feed("nope"))[0], 404)
        self.assertEqual((await self.env.vpn.feed(""))[0], 404)
        u = await self.new_user()
        await self.paid_order(u)
        token = await self.env.users.sub_token(u["id"])
        await self.env.users.set_blocked(u["id"], True)
        self.assertEqual((await self.env.vpn.feed(token))[0], 404)

    async def test_feed_is_empty_without_active_subscription(self):
        u = await self.new_user()
        token = await self.env.users.sub_token(u["id"])
        status, _, body = await self.env.vpn.feed(token)
        self.assertEqual((status, decode(body)), (200, []))
        await self.paid_order(u, "test")
        clock.advance(8 * DAY)                                   # подписка истекла
        self.assertEqual(decode((await self.env.vpn.feed(token))[2]), [])

    async def test_feed_never_leaks_other_users_links(self):
        a, b = await self.new_user(1), await self.new_user(2)
        await self.paid_order(a, ext="1")
        tb = await self.env.users.sub_token(b["id"])
        self.assertEqual(decode((await self.env.vpn.feed(tb))[2]), [])
