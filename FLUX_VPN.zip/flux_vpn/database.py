"""Асинхронная обёртка над SQLite (aiosqlite): транзакции, миграции, резервные копии.

ВАЖНО: одно соединение + asyncio.Lock. Внутри `async with db.tx() as t` используйте ТОЛЬКО `t`,
а не `db.*` (иначе взаимная блокировка).
"""
from __future__ import annotations

import asyncio
import logging
import sqlite3
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Sequence

import aiosqlite

log = logging.getLogger(__name__)


class Tx:
    def __init__(self, conn: aiosqlite.Connection):
        self._c = conn

    async def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        cur = await self._c.execute(sql, tuple(params))
        n = cur.rowcount
        await cur.close()
        return n

    async def insert(self, sql: str, params: Sequence[Any] = ()) -> int:
        cur = await self._c.execute(sql, tuple(params))
        rid = cur.lastrowid
        await cur.close()
        return rid

    async def fetchone(self, sql: str, params: Sequence[Any] = ()) -> dict | None:
        cur = await self._c.execute(sql, tuple(params))
        row = await cur.fetchone()
        await cur.close()
        return dict(row) if row else None

    async def fetchall(self, sql: str, params: Sequence[Any] = ()) -> list[dict]:
        cur = await self._c.execute(sql, tuple(params))
        rows = await cur.fetchall()
        await cur.close()
        return [dict(r) for r in rows]


class Database:
    def __init__(self, path: str | Path):
        self.path = str(path)
        self._conn: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(self.path, isolation_level=None)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA foreign_keys=ON")
        await self._conn.execute("PRAGMA busy_timeout=5000")
        if self.path != ":memory:":
            await self._conn.execute("PRAGMA journal_mode=WAL")
            await self._conn.execute("PRAGMA synchronous=NORMAL")
            try:
                Path(self.path).chmod(0o600)
            except OSError:
                pass

    async def close(self) -> None:
        if self._conn:
            await self._conn.close()
            self._conn = None

    # ---- запросы вне явной транзакции (каждый атомарен) ----
    async def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        async with self._lock:
            return await Tx(self._conn).execute(sql, params)

    async def fetchone(self, sql: str, params: Sequence[Any] = ()) -> dict | None:
        async with self._lock:
            return await Tx(self._conn).fetchone(sql, params)

    async def fetchall(self, sql: str, params: Sequence[Any] = ()) -> list[dict]:
        async with self._lock:
            return await Tx(self._conn).fetchall(sql, params)

    @asynccontextmanager
    async def tx(self):
        async with self._lock:
            await self._conn.execute("BEGIN IMMEDIATE")
            try:
                yield Tx(self._conn)
            except BaseException:
                try:
                    await self._conn.execute("ROLLBACK")
                except Exception:  # noqa: BLE001
                    log.exception("ROLLBACK failed")
                raise
            else:
                await self._conn.execute("COMMIT")

    # ---- миграции ----
    async def migrate(self, migrations_dir: Path, backup_dir: Path | None = None) -> list[str]:
        async with self._lock:
            await self._conn.execute(
                "CREATE TABLE IF NOT EXISTS schema_migrations("
                "version TEXT PRIMARY KEY, applied_at INTEGER NOT NULL)")
            cur = await self._conn.execute("SELECT version FROM schema_migrations")
            applied = {r[0] for r in await cur.fetchall()}
            await cur.close()
        pending = sorted(p for p in Path(migrations_dir).glob("*.sql") if p.stem not in applied)
        if not pending:
            return []
        if applied and backup_dir is not None and self.path != ":memory:":
            await self.backup(backup_dir, keep=30, prefix="pre-migrate")
        done: list[str] = []
        for f in pending:
            script = (f"BEGIN;\n{f.read_text(encoding='utf-8')}\n"
                      f"INSERT INTO schema_migrations(version, applied_at) "
                      f"VALUES ('{f.stem}', {int(time.time())});\nCOMMIT;")
            async with self._lock:
                try:
                    await self._conn.executescript(script)
                except Exception:
                    try:
                        await self._conn.execute("ROLLBACK")
                    except Exception:  # noqa: BLE001
                        pass
                    log.error("Миграция %s не применена", f.name)
                    raise
            done.append(f.stem)
            log.info("Применена миграция %s", f.name)
        return done

    # ---- резервное копирование ----
    async def backup(self, backup_dir: Path, keep: int = 14, prefix: str = "flux") -> Path | None:
        if self.path == ":memory:":
            return None
        backup_dir = Path(backup_dir)
        backup_dir.mkdir(parents=True, exist_ok=True)
        dest = backup_dir / f"{prefix}-{time.strftime('%Y%m%d-%H%M%S')}.db"
        await asyncio.to_thread(_backup_sync, self.path, str(dest))
        try:
            dest.chmod(0o600)
        except OSError:
            pass
        old = sorted(backup_dir.glob(f"{prefix}-*.db"))
        for p in old[:-keep] if keep > 0 else []:
            p.unlink(missing_ok=True)
        log.info("Резервная копия БД: %s", dest)
        return dest


def _backup_sync(src_path: str, dest_path: str) -> None:
    src = sqlite3.connect(src_path)
    dst = sqlite3.connect(dest_path)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
