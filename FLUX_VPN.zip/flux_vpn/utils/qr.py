from __future__ import annotations

import io


def make_qr_png(data: str) -> bytes:
    import segno
    buf = io.BytesIO()
    segno.make(data, error="m").save(buf, kind="png", scale=8, border=4)
    return buf.getvalue()
