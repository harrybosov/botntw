"""Логирование с маскированием секретов."""
from __future__ import annotations

import logging
import re
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

_TOKEN_RE = re.compile(r"\b\d{6,}:[A-Za-z0-9_-]{30,}\b")


class RedactFilter(logging.Filter):
    def __init__(self, secrets: list[str]):
        super().__init__()
        self._secrets = sorted({s for s in secrets if s and len(s) >= 6}, key=len, reverse=True)

    def redact(self, text: str) -> str:
        for s in self._secrets:
            text = text.replace(s, "***")
        return _TOKEN_RE.sub("***", text)

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:  # noqa: BLE001
            return True
        record.msg = self.redact(msg)
        record.args = ()
        if record.exc_info:
            # текст traceback форматируется позже; прогоняем через Formatter-обёртку ниже
            pass
        return True


class RedactingFormatter(logging.Formatter):
    def __init__(self, fmt: str, flt: RedactFilter):
        super().__init__(fmt)
        self._flt = flt

    def format(self, record: logging.LogRecord) -> str:
        return self._flt.redact(super().format(record))


def setup_logging(level: str, log_file: str | None, secrets: list[str]) -> None:
    flt = RedactFilter(secrets)
    fmt = RedactingFormatter("%(asctime)s %(levelname)s [%(name)s] %(message)s", flt)
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    root.addHandler(sh)
    if log_file:
        p = Path(log_file)
        p.parent.mkdir(parents=True, exist_ok=True)
        fh = RotatingFileHandler(p, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
        fh.setFormatter(fmt)
        root.addHandler(fh)
    root.addFilter(flt)
    logging.getLogger("aiogram").setLevel(logging.INFO)
