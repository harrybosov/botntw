from __future__ import annotations

import logging

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import CallbackQuery, Message

log = logging.getLogger(__name__)


async def render(event: CallbackQuery | Message, text: str, kb=None) -> None:
    """Для callback — редактирует сообщение (или отправляет новое), для Message — отвечает."""
    if isinstance(event, CallbackQuery):
        try:
            await event.message.edit_text(text, reply_markup=kb)
        except TelegramBadRequest as e:
            if "message is not modified" not in str(e):
                await event.message.answer(text, reply_markup=kb)
        try:
            await event.answer()
        except TelegramBadRequest:
            pass
    else:
        await event.answer(text, reply_markup=kb)


async def alert(cb: CallbackQuery, text: str) -> None:
    try:
        await cb.answer(text, show_alert=True)
    except TelegramBadRequest:
        pass
