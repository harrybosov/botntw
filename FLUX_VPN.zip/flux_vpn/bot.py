"""Точка входа FLUX VPN: python bot.py"""
from __future__ import annotations

import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from config import BASE_DIR, ConfigError, Settings, abs_path
from database import Database
from services.container import Services
from utils.logging import setup_logging

log = logging.getLogger("flux")


async def build_services(settings: Settings, bot: Bot, db: Database) -> Services:
    from payments.cispay import CisPayProvider
    from payments.telegram_stars import StarsProvider
    from services.fulfillment import Fulfillment
    from services.notifications import Notifier
    from services.orders import OrderService
    from services.plans import PlanService
    from services.promo import PromoService
    from services.referrals import REF_BONUS_KEY, ReferralService
    from services.scheduler import Scheduler
    from services.settings import SettingsService
    from services.subcard import SubCard
    from services.trial import TrialService
    from services.subscriptions import SubscriptionService
    from services.users import UserService
    from vpn.nodes import NodeRegistry
    from vpn.subscriptions import VpnManager

    kv = SettingsService(db)
    if await kv.get(REF_BONUS_KEY) is None:
        await kv.set(REF_BONUS_KEY, str(settings.referral_default_bonus_days))
    users, plans, subs = UserService(db), PlanService(db), SubscriptionService(db)
    from models import Provider
    orders = OrderService(db, plans, {Provider.STARS: settings.order_ttl_stars_min,
                                      Provider.CISPAY: settings.order_ttl_cispay_min})
    registry = NodeRegistry.from_settings(db, settings)
    await registry.sync_db()
    vpn = VpnManager(db, registry)
    notifier = Notifier(bot, db, settings.admin_ids)
    subcard = SubCard(db, subs, plans, vpn, users, settings)
    fulfillment = Fulfillment(db, orders, subs, vpn, notifier, users, settings.timezone, subcard)
    trial = TrialService(db, vpn, notifier, subcard, settings.trial_days)

    svc = Services(settings=settings, kv=kv, db=db, bot=bot, users=users, plans=plans, subs=subs, orders=orders,
                   promo=PromoService(db), referrals=None, vpn=vpn, registry=registry,
                   fulfillment=fulfillment, notifier=notifier, subcard=subcard, trial=trial)
    svc.referrals = ReferralService(db, svc.bot_username)

    if settings.stars_enabled:
        svc.stars = StarsProvider(bot, plans, orders, users, fulfillment)
        svc.providers[Provider.STARS] = svc.stars
    if settings.cispay_enabled:
        svc.cispay = CisPayProvider(settings.cispay_shop_id, settings.cispay_api_key,
                                    orders, users, fulfillment, settings.cispay_allow_sandbox)
        svc.providers[Provider.CISPAY] = svc.cispay
    svc.scheduler = Scheduler(db, orders, subs, vpn, notifier, users, svc.providers, settings.timezone,
                              abs_path(settings.backup_dir), settings.backup_keep, settings.backup_interval_hours)
    return svc


def build_dispatcher(svc: Services) -> Dispatcher:
    from admin import broadcasts, dashboard, payments as adm_payments, promos, settings as adm_settings, statistics
    from admin import users as adm_users
    from handlers import cabinet, connections, menu, promo, referrals, shop, start, support
    from middlewares.throttle import ThrottleMiddleware
    from middlewares.user import UserMiddleware

    dp = Dispatcher(storage=MemoryStorage())
    dp["svc"] = svc
    for observer in (dp.message, dp.callback_query):
        observer.outer_middleware(UserMiddleware(svc))
        observer.outer_middleware(ThrottleMiddleware())
    for r in (start.router, menu.router, shop.router, cabinet.router, connections.router, referrals.router,
              promo.router, support.router, dashboard.router, statistics.router, adm_users.router,
              adm_payments.router, promos.router, adm_settings.router, broadcasts.router):
        dp.include_router(r)
    return dp


async def detect_sub_url(svc: Services) -> None:
    """Если XUI_SUB_URL не задан — берём адрес подписки из настроек самой панели."""
    s = svc.settings
    if s.xui_sub_url or s.vpn_mode != "xui":
        return
    for adapter in {id(a): a for a in svc.registry.adapters.values()}.values():
        try:
            base = await adapter.detect_sub_base()
        except Exception as e:  # noqa: BLE001
            log.warning("Не удалось определить адрес подписки панели: %s", e)
            continue
        if base:
            s.xui_sub_url = base
            log.info("Адрес подписки панели определён автоматически: %s/<subId>", base)
            return
    if not s.public_url:
        log.warning("Адрес подписки не определён: задайте XUI_SUB_URL (или PUBLIC_URL) — иначе пользователи "
                    "получат ключи списком, а не короткой ссылкой")


async def main() -> None:
    try:
        settings = Settings.load()
        settings.validate_for_run()
    except ConfigError as e:
        print(f"Ошибка конфигурации: {e}", file=sys.stderr)
        sys.exit(2)
    setup_logging(settings.log_level, str(abs_path(settings.log_file)), settings.secrets())
    if settings.vpn_mode == "mock":
        log.warning("VPN_MODE=mock: выдаются ТЕСТОВЫЕ ЗАГЛУШКИ, не рабочие конфигурации")

    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML,
                                                               link_preview_is_disabled=True))
    db = Database(abs_path(settings.database_path))
    await db.connect()
    await db.migrate(BASE_DIR / "migrations", abs_path(settings.backup_dir))
    svc = await build_services(settings, bot, db)
    await detect_sub_url(svc)
    dp = build_dispatcher(svc)

    runner = None
    if settings.public_url:
        # Optional HTTP endpoint serves VPN subscription feeds only. cisPay payments
        # are confirmed exclusively by authenticated GET /payments/status polling.
        from payments.webhook import build_app, start_server
        runner = await start_server(build_app(vpn=svc.vpn),
                                    settings.sub_feed_host, settings.sub_feed_port)
    svc.scheduler.start()
    me = await bot.me()
    log.info("FLUX VPN запущен как @%s (способы оплаты: %s)", me.username, ", ".join(svc.providers) or "нет")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await svc.scheduler.stop()
        if runner:
            await runner.cleanup()
        await svc.registry.close()
        if svc.cispay:
            await svc.cispay.http.close()
        await bot.session.close()
        await db.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
