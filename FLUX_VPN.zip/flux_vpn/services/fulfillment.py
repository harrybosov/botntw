"""Оркестрация: подтверждённая оплата → подписка → VPN → уведомления. Не импортирует aiogram."""
from __future__ import annotations

import logging

from models import Provider
from services.orders import PaymentOutcome
from services.subscriptions import extend_tx
from utils import clock, texts

log = logging.getLogger(__name__)


class Fulfillment:
    def __init__(self, db, orders, subs, vpn, notifier, users, tz: str, subcard=None):
        self.db, self.orders, self.subs, self.vpn = db, orders, subs, vpn
        self.notifier, self.users, self.tz, self.subcard = notifier, users, tz, subcard

    async def confirm(self, order_id: int, *, source: str, external_id: str, amount: int,
                      currency: str, note: str | None = None) -> PaymentOutcome:
        """ЕДИНСТВЕННАЯ точка выдачи доступа за деньги. Повторный вызов безопасен."""
        outcome = await self.orders.apply_payment(
            order_id, source=source, external_id=external_id, amount=amount, currency=currency, note=note)
        if outcome.status == "ok":
            await self._after_paid(outcome)
        elif outcome.status in ("rejected", "already_paid"):
            log.warning("Платёж не принят: order=%s source=%s ext=%s reason=%s",
                        order_id, source, external_id, outcome.reason)
            await self.notifier.notify_admins(
                f"⚠️ Платёж не принят автоматически\nЗаказ: {outcome.order['public_id'] if outcome.order else order_id}\n"
                f"Источник: {source}, ID: {external_id}\nПричина: {outcome.reason}")
        return outcome

    async def _after_paid(self, outcome: PaymentOutcome) -> None:
        order, sub = outcome.order, outcome.subscription
        user = await self.users.get(order["user_id"])
        res = await self.vpn.sync_user(user["id"])
        ends = texts.fmt_dt(sub["ends_at"], self.tz)
        note = "✅ Оплата получена. Подписка продлена." if outcome.was_active_before else \
            f"✅ Оплата получена. Тариф «{texts.E(order['plan_name'])}» активирован."
        if self.subcard is not None:
            text, markup = await self.subcard.render(user, note=note)
        else:
            text, markup = f"{note}\nПодписка активна до: <b>{ends}</b>", None
        await self.notifier.once(user, "PAID", order["public_id"], text, markup)
        if not res.ok:
            await self.notifier.once(user, "VPN_PENDING", order["public_id"], texts.n_vpn_pending())
            await self.notifier.notify_admins(
                f"⚠️ VPN-панель не выдала доступ после оплаты\nЗаказ {order['public_id']}, tg {user['tg_id']}\n"
                + "\n".join(res.errors)[:800] + "\nПовтор будет автоматически.")
        if outcome.reward:
            ref = outcome.reward["referrer"]
            await self.notifier.once(ref, "REFERRAL", order["public_id"],
                                     texts.n_referral(outcome.reward["bonus_days"]))

    async def grant_days(self, user_id: int, days: int, *, kind: str, ref: str, text_builder) -> dict:
        """Бонусные дни (промокод / реферальный баланс / ручное продление) + синхронизация VPN."""
        sub = await self.subs.extend(user_id, days)
        await self.vpn.sync_user(user_id)
        user = await self.users.get(user_id)
        await self.notifier.once(user, kind, ref, text_builder(texts.fmt_dt(sub["ends_at"], self.tz)))
        return sub

    async def finish_grant(self, user_id: int) -> None:
        """Для случаев, когда дни уже начислены в транзакции (промокод/баланс): только VPN."""
        await self.vpn.sync_user(user_id)

    async def refund(self, order_id: int) -> PaymentOutcome:
        outcome = await self.orders.apply_refund(order_id)
        if outcome.status == "ok":
            await self.vpn.sync_user(outcome.order["user_id"])
        return outcome
