from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Services:
    settings: Any
    kv: Any
    db: Any
    bot: Any
    users: Any
    plans: Any
    subs: Any
    orders: Any
    promo: Any
    referrals: Any
    vpn: Any
    registry: Any
    fulfillment: Any
    notifier: Any
    providers: dict = field(default_factory=dict)
    stars: Any = None
    crypto: Any = None
    donate: Any = None
    cispay: Any = None
    scheduler: Any = None
    subcard: Any = None
    trial: Any = None
    _username: str | None = None

    async def bot_username(self) -> str:
        if not self._username:
            self._username = (await self.bot.me()).username
        return self._username

    async def admin_log(self, admin_tg_id: int, action: str, target: str = "", details: str = "") -> None:
        from utils import clock
        await self.db.execute(
            "INSERT INTO admin_logs(admin_tg_id,action,target,details,created_at) VALUES(?,?,?,?,?)",
            (admin_tg_id, action, target, details[:500], clock.now()))
