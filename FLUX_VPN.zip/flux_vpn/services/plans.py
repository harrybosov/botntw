from __future__ import annotations

from models import CURRENCY_STARS
from utils import clock


class PlanService:
    def __init__(self, db):
        self.db = db

    async def list_active(self) -> list[dict]:
        return await self.db.fetchall(
            "SELECT * FROM plans WHERE is_active=1 ORDER BY sort_order, id")

    async def list_all(self) -> list[dict]:
        return await self.db.fetchall("SELECT * FROM plans WHERE id<>'trial' ORDER BY sort_order, id")

    async def get(self, plan_id: str) -> dict | None:
        return await self.db.fetchone("SELECT * FROM plans WHERE id=?", (plan_id,))

    async def update(self, plan_id: str, *, name: str | None = None, days: int | None = None,
                     price_rub: int | None = None, is_active: bool | None = None) -> None:
        sets, params = [], []
        for col, val in (("name", name), ("days", days), ("price_rub", price_rub),
                         ("is_active", None if is_active is None else int(is_active))):
            if val is not None:
                sets.append(f"{col}=?")   # имена колонок — константы, значения параметризованы
                params.append(val)
        if not sets:
            return
        sets.append("updated_at=?")
        params += [clock.now(), plan_id]
        await self.db.execute(f"UPDATE plans SET {', '.join(sets)} WHERE id=?", params)

    async def stars_price(self, plan_id: str) -> int | None:
        row = await self.db.fetchone(
            "SELECT amount FROM plan_prices WHERE plan_id=? AND currency=?", (plan_id, CURRENCY_STARS))
        return row["amount"] if row else None

    async def set_stars_price(self, plan_id: str, amount: int | None) -> None:
        if amount is None or amount <= 0:
            await self.db.execute(
                "DELETE FROM plan_prices WHERE plan_id=? AND currency=?", (plan_id, CURRENCY_STARS))
            return
        await self.db.execute(
            "INSERT INTO plan_prices(plan_id,currency,amount) VALUES(?,?,?) "
            "ON CONFLICT(plan_id,currency) DO UPDATE SET amount=excluded.amount",
            (plan_id, CURRENCY_STARS, amount))
