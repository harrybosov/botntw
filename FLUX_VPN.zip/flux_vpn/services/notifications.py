"""Отправка уведомлений в Telegram с дедупликацией (таблица notifications)."""
from __future__ import annotations

import asyncio
import logging

from aiogram.exceptions import TelegramAPIError, TelegramForbiddenError, TelegramRetryAfter

from utils import clock

log = logging.getLogger(__name__)


class Notifier:
    def __init__(self, bot, db, admin_ids: list[int]):
        self.bot, self.db, self.admin_ids = bot, db, admin_ids

    async def send(self, tg_id: int, text: str, reply_markup=None) -> bool:
        for attempt in (1, 2):
            try:
                await self.bot.send_message(tg_id, text, reply_markup=reply_markup)
                return True
            except TelegramForbiddenError:
                await self.db.execute("UPDATE users SET bot_blocked=1 WHERE tg_id=?", (tg_id,))
                return False
            except TelegramRetryAfter as e:
                if attempt == 2:
                    return False
                await asyncio.sleep(e.retry_after + 0.5)
            except TelegramAPIError as e:
                log.warning("send_message(%s) failed: %s", tg_id, e)
                return False
        return False

    async def once(self, user: dict, kind: str, ref: str, text: str, reply_markup=None) -> bool:
        """Отправляет уведомление не более одного раза для пары (kind, ref)."""
        n = await self.db.execute(
            "INSERT OR IGNORE INTO notifications(user_id,kind,ref,sent,created_at) VALUES(?,?,?,0,?)",
            (user["id"], kind, str(ref), clock.now()))
        if n == 0:
            return False
        ok = await self.send(user["tg_id"], text, reply_markup)
        if ok:
            await self.db.execute("UPDATE notifications SET sent=1 WHERE user_id=? AND kind=? AND ref=?",
                                  (user["id"], kind, str(ref)))
        return ok

    async def mark_only(self, user_id: int, kind: str, ref: str) -> bool:
        n = await self.db.execute(
            "INSERT OR IGNORE INTO notifications(user_id,kind,ref,sent,created_at) VALUES(?,?,?,1,?)",
            (user_id, kind, str(ref), clock.now()))
        return n > 0

    async def notify_admins(self, text: str, reply_markup=None) -> None:
        for aid in self.admin_ids:
            await self.send(aid, text, reply_markup)
