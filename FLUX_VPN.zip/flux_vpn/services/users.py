from __future__ import annotations

from utils import clock


class UserService:
    def __init__(self, db):
        self.db = db

    async def upsert_from_telegram(self, tg_id: int, username: str | None, first_name: str | None,
                                   last_name: str | None, ref_tg_id: int | None = None
                                   ) -> tuple[dict, bool]:
        """Создаёт/обновляет пользователя. Реферал фиксируется ТОЛЬКО при первой регистрации."""
        now = clock.now()
        async with self.db.tx() as t:
            row = await t.fetchone("SELECT * FROM users WHERE tg_id=?", (tg_id,))
            created = row is None
            if created:
                uid = await t.insert(
                    "INSERT INTO users(tg_id,username,first_name,last_name,created_at,last_seen_at) "
                    "VALUES(?,?,?,?,?,?)", (tg_id, username, first_name, last_name, now, now))
                if ref_tg_id and ref_tg_id != tg_id:
                    ref = await t.fetchone("SELECT id FROM users WHERE tg_id=?", (ref_tg_id,))
                    if ref and ref["id"] != uid:
                        await t.execute("UPDATE users SET referrer_id=? WHERE id=?", (ref["id"], uid))
                        await t.execute(
                            "INSERT INTO referrals(referrer_id, referred_id, created_at) VALUES(?,?,?)",
                            (ref["id"], uid, now))
            else:
                uid = row["id"]
                await t.execute(
                    "UPDATE users SET username=?, first_name=?, last_name=?, last_seen_at=?, bot_blocked=0 "
                    "WHERE id=?", (username, first_name, last_name, now, uid))
            user = await t.fetchone("SELECT * FROM users WHERE id=?", (uid,))
        return user, created

    async def get(self, user_id: int) -> dict | None:
        return await self.db.fetchone("SELECT * FROM users WHERE id=?", (user_id,))

    async def get_by_tg(self, tg_id: int) -> dict | None:
        return await self.db.fetchone("SELECT * FROM users WHERE tg_id=?", (tg_id,))

    async def sub_token(self, user_id: int) -> str:
        """Личный токен единой ссылки-подписки (создаётся при первом обращении)."""
        import secrets
        async with self.db.tx() as t:
            row = await t.fetchone("SELECT sub_token FROM users WHERE id=?", (user_id,))
            if row and row["sub_token"]:
                return row["sub_token"]
            token = secrets.token_hex(16)
            await t.execute("UPDATE users SET sub_token=? WHERE id=?", (token, user_id))
            return token

    async def set_blocked(self, user_id: int, blocked: bool) -> None:
        await self.db.execute("UPDATE users SET is_blocked=? WHERE id=?", (1 if blocked else 0, user_id))

    async def mark_bot_blocked(self, tg_id: int) -> None:
        await self.db.execute("UPDATE users SET bot_blocked=1 WHERE tg_id=?", (tg_id,))

    async def broadcast_targets(self) -> list[int]:
        rows = await self.db.fetchall(
            "SELECT tg_id FROM users WHERE is_blocked=0 AND bot_blocked=0 ORDER BY id")
        return [r["tg_id"] for r in rows]
