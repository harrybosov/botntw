"""«Мои подключения»: одна карточка «Моя подписка» со ссылкой, плюс «Как подключиться»."""
import logging

from aiogram import F, Router
from aiogram.types import CallbackQuery

from keyboards import btn, kb
from utils import texts
from utils.ui import alert, render

log = logging.getLogger(__name__)
router = Router(name="connections")
E = texts.E

HELP = (
    "🚀 <b>Как подключиться к FLUX VPN</b>\n\n"
    "Подключение займёт всего пару минут!\n\n"
    "<b>1. 📲 Скачайте приложение</b>\n"
    "Рекомендуем <b>Incy</b> — оно использует обновлённую версию Xray и обеспечивает стабильную работу VPN.\n"
    "Также можно использовать <b>Happ</b>.\n\n"
    "<b>2. 📋 Скопируйте ключ подключения</b>\n"
    "Откройте раздел «Мои подключения» и нажмите «Скопировать ключ».\n\n"
    "<b>3. 🔗 Добавьте подписку в приложение</b>\n"
    "Откройте Incy или Happ, найдите добавление подписки и вставьте скопированную ссылку.\n\n"
    "<b>4. 🌍 Подключитесь к серверу</b>\n"
    "Выберите нужную страну и нажмите кнопку подключения.\n\n"
    "✅ Готово! Приятного использования FLUX VPN!"
)


@router.callback_query(F.data == "conns")
async def conns(cb: CallbackQuery, svc, user):
    text, markup = await svc.subcard.render(user)
    await render(cb, text, markup)


@router.callback_query(F.data == "conns_all")
async def conns_all(cb: CallbackQuery, svc, user):
    """Запасной вариант: все ссылки отдельными блоками (если ссылка-подписка не настроена)."""
    views = [v for v in await svc.vpn.connections(user["id"]) if v.link]
    if not views:
        return await alert(cb, "Подключения недоступны")
    chunk, size = [], 0
    for v in views:
        piece = f"<b>{E(v.title)}</b> · {E(v.protocol_label)}\n<code>{E(v.link)}</code>"
        if size + len(piece) > 3500 and chunk:
            await cb.message.answer("\n\n".join(chunk))
            chunk, size = [], 0
        chunk.append(piece)
        size += len(piece)
    if chunk:
        await cb.message.answer("\n\n".join(chunk))
    await cb.answer()


@router.callback_query(F.data == "help")
async def help_(cb: CallbackQuery):
    await render(cb, HELP, kb([[btn("🔑 Мои подключения", "conns", style="success")],
                               [btn("🔙 Назад в меню", "menu", style="danger")]]))
