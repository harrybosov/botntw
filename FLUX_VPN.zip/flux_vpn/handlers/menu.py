from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery

from handlers.start import MAIN_TEXT
from keyboards import main_menu
from utils.ui import render

router = Router(name="menu")


@router.callback_query(F.data == "menu")
async def menu(cb: CallbackQuery, state: FSMContext, is_admin: bool):
    await state.clear()
    await render(cb, MAIN_TEXT, main_menu(is_admin))
