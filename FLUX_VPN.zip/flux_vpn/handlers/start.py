from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from keyboards import main_menu
from middlewares.user import CHECK_CALLBACK, is_channel_member

router = Router(name="start")

MAIN_TEXT = (
    "💎 <b>FLUX VPN</b>\n\n"
    "🔒 Защищённое подключение\n"
    "🔗 Одна ссылка-подписка на все серверы\n"
    "🚀 Высокая скорость соединения"
)


@router.message(CommandStart())
async def start(msg: Message, state: FSMContext, is_new: bool, is_admin: bool):
    await state.clear()
    await msg.answer(MAIN_TEXT, reply_markup=main_menu(is_admin))


@router.message(Command("menu"))
async def menu_cmd(msg: Message, state: FSMContext, is_admin: bool):
    await state.clear()
    await msg.answer(MAIN_TEXT, reply_markup=main_menu(is_admin))


@router.callback_query(lambda c: c.data == CHECK_CALLBACK)
async def check_channel_subscription(call: CallbackQuery, state: FSMContext, svc, user, is_admin: bool):
    channel = svc.settings.required_channel
    if not is_admin and channel:
        try:
            subscribed = await is_channel_member(call.bot, call.from_user.id, channel)
        except Exception:  # noqa: BLE001
            await call.answer("Не удалось проверить подписку. Попробуйте позже.", show_alert=True)
            return
        if not subscribed:
            await call.answer("Подписка пока не найдена. Подпишитесь и нажмите проверить ещё раз.", show_alert=True)
            return
    await state.clear()
    await call.answer("Подписка подтверждена! Добро пожаловать в FLUX VPN.")
    if call.message:
        await call.message.edit_text(MAIN_TEXT, reply_markup=main_menu(is_admin))
    try:
        if await svc.trial.grant(user):             # пробный период — сразу после подтверждения подписки на канал
            await svc.trial.notify(user)
    except Exception:  # noqa: BLE001
        pass
