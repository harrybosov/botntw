"""Покупка: тариф → способ оплаты → подтверждение → счёт. Плюс Stars (pre_checkout / successful_payment)."""
import logging

from aiogram import F, Router
from aiogram.types import CallbackQuery, Message, PreCheckoutQuery

from keyboards import btn, confirm_kb, home, kb, pay_kb, plan_kb, plans_kb
from models import CURRENCY_STARS, OrderStatus, PROVIDER_TITLES, Provider
from services.orders import OrderError
from utils import texts
from utils.http import HttpError
from utils.ui import alert, render

log = logging.getLogger(__name__)
router = Router(name="shop")
E = texts.E


async def _price_text(svc, plan: dict, code: str) -> str:
    if code == Provider.STARS:
        return texts.fmt_money(await svc.plans.stars_price(plan["id"]) or 0, CURRENCY_STARS)
    return texts.fmt_money(plan["price_rub"], "RUB")


@router.callback_query(F.data == "shop")
async def shop(cb: CallbackQuery, svc):
    plans = await svc.plans.list_active()
    if not plans:
        return await render(cb, "Тарифы временно недоступны.", kb([[home()]]))
    await render(cb, "🛒 <b>Выберите тариф</b>\n\nПосле оплаты доступ выдаётся автоматически.", plans_kb(plans))


@router.callback_query(F.data.startswith("plan:"))
async def plan_view(cb: CallbackQuery, svc):
    plan = await svc.plans.get(cb.data.split(":", 1)[1])
    if not plan or not plan["is_active"]:
        return await alert(cb, "Тариф недоступен")
    codes = [c for c, p in svc.providers.items() if await p.available_for(plan["id"])]
    lines = [f"📦 <b>{E(plan['name'])}</b>",
             f"💰 Стоимость: <b>{plan['price_rub']} ₽</b>",
             f"🗓 Продолжительность: <b>{texts.fmt_days(plan['days'])}</b>", ""]
    if codes:
        lines.append("Доступные способы оплаты:")
        for c in codes:
            lines.append(f"• {PROVIDER_TITLES[c]} — {await _price_text(svc, plan, c)}")
        lines.append("\nВыберите способ оплаты:")
    else:
        lines.append("⚠️ Способы оплаты для этого тарифа временно недоступны.")
    await render(cb, "\n".join(lines), plan_kb(plan["id"], codes))


@router.callback_query(F.data.startswith("pm:"))
async def pay_method(cb: CallbackQuery, svc):
    _, plan_id, code = cb.data.split(":")
    plan = await svc.plans.get(plan_id)
    provider = svc.providers.get(code)
    if not plan or not plan["is_active"] or not provider or not await provider.available_for(plan_id):
        return await alert(cb, "Этот способ оплаты недоступен")
    text = (f"🧾 <b>Подтверждение заказа</b>\n\n📦 Тариф: <b>{E(plan['name'])}</b>\n"
            f"🗓 Срок: <b>{texts.fmt_days(plan['days'])}</b>\n"
            f"💰 К оплате: <b>{await _price_text(svc, plan, code)}</b>\n"
            f"💳 Способ: {PROVIDER_TITLES[code]}\n\nНажмите «Подтвердить», чтобы создать счёт.")
    await render(cb, text, confirm_kb(plan_id, code))


@router.callback_query(F.data.startswith("buy:"))
async def buy(cb: CallbackQuery, svc, user):
    _, plan_id, code = cb.data.split(":")
    provider = svc.providers.get(code)
    if not provider or not await provider.available_for(plan_id):
        return await alert(cb, "Этот способ оплаты недоступен")
    try:
        order = await svc.orders.create_order(user["id"], plan_id, code)
    except OrderError as e:
        return await alert(cb, str(e))
    try:
        start = await provider.start(order, user)
    except Exception as e:  # noqa: BLE001  (сеть, ответ провайдера, Telegram)
        log.warning("start payment failed (%s): %s", code, e)
        await svc.orders.cancel(order["id"], user["id"])
        return await render(cb, "😔 Не удалось создать счёт. Попробуйте позже или выберите другой способ оплаты.",
                            kb([[btn("🔙 К тарифам", "shop")], [home()]]))
    if start.external_id or start.url:
        await svc.orders.set_external(order["id"], start.external_id, start.url)
    head = f"🧾 Заказ <code>{order['public_id']}</code> · {E(order['plan_name'])}\n\n"
    await render(cb, head + start.text, pay_kb(order, start))


async def _own_order(cb: CallbackQuery, svc, user) -> dict | None:
    order = await svc.orders.get_by_public(cb.data.split(":", 1)[1])
    if not order or order["user_id"] != user["id"]:
        await alert(cb, "Заказ не найден")
        return None
    return order


@router.callback_query(F.data.startswith("chk:"))
async def check_order(cb: CallbackQuery, svc, user):
    order = await _own_order(cb, svc, user)
    if not order:
        return
    if order["status"] == OrderStatus.PENDING:
        provider = svc.providers.get(order["provider"])
        if provider:
            await provider.check(order)
        order = await svc.orders.get(order["id"])
    if order["status"] == OrderStatus.PAID:
        return await render(cb, "✅ <b>Оплата подтверждена!</b> Подписка активна.",
                            kb([[btn("🔑 Мои подключения", "conns", style="success")], [home()]]))
    if order["status"] == OrderStatus.PENDING:
        return await alert(cb, "Платёж пока не найден. Подождите минуту и повторите проверку.")
    await render(cb, f"Статус заказа: {texts.STATUS_EMOJI[order['status']]} {texts.STATUS_RU[order['status']]}",
                 kb([[btn("🛒 Купить подписку", "shop")], [home()]]))


@router.callback_query(F.data.startswith("paid:"))
async def claim_paid(cb: CallbackQuery, svc, user):
    """«Я оплатил(а)» (DonateAlerts): проверка через API либо заявка администратору. Само по себе НЕ даёт доступ."""
    order = await _own_order(cb, svc, user)
    if not order or order["provider"] != Provider.DONATEALERTS:
        return
    if order["status"] == OrderStatus.PAID:
        return await alert(cb, "Заказ уже оплачен ✅")
    provider = svc.providers[Provider.DONATEALERTS]
    if provider.api_ready:
        if await provider.check(order):
            return await render(cb, "✅ <b>Оплата найдена!</b> Подписка активна.",
                                kb([[btn("🔑 Мои подключения", "conns", style="success")], [home()]]))
        return await alert(cb, "Донат с кодом заказа пока не найден. Проверьте, что код указан в сообщении.")
    sent = await svc.notifier.once(
        user, "DA_CLAIM", order["public_id"], "📨 Заявка отправлена администратору. Мы сообщим, когда оплата будет подтверждена.")
    if sent:
        await svc.notifier.notify_admins(
            f"💳 DonateAlerts: заявка на подтверждение\nЗаказ <code>{order['public_id']}</code> · {E(order['plan_name'])}\n"
            f"Сумма: <b>{order['amount']} ₽</b> · пользователь tg <code>{user['tg_id']}</code>\n"
            "Сверьте донат с кодом заказа в кабинете DonationAlerts.",
            kb([[btn("✅ Подтвердить", f"adm:da_ok:{order['id']}", style="success"),
                 btn("🚫 Отклонить", f"adm:da_no:{order['id']}", style="danger")]]))
    await alert(cb, "Заявка отправлена администратору")


@router.callback_query(F.data.startswith("cancel:"))
async def cancel_order(cb: CallbackQuery, svc, user):
    order = await _own_order(cb, svc, user)
    if not order:
        return
    done = await svc.orders.cancel(order["id"], user["id"])
    await render(cb, "🚫 Заказ отменён." if done else "Заказ уже нельзя отменить.",
                 kb([[btn("🛒 К тарифам", "shop")], [home()]]))


# ---------- Telegram Stars ----------
@router.pre_checkout_query()
async def pre_checkout(q: PreCheckoutQuery, svc):
    if svc.stars is None:
        return await q.answer(ok=False, error_message="Оплата Stars недоступна")
    ok, err = await svc.stars.validate_pre_checkout(q.from_user.id, q.invoice_payload, q.currency, q.total_amount)
    await q.answer(ok=ok, error_message=None if ok else err)


@router.message(F.successful_payment)
async def successful_payment(msg: Message, svc):
    if svc.stars is None:
        return
    try:
        await svc.stars.handle_successful_payment(msg.from_user.id, msg.successful_payment)
    except Exception:  # noqa: BLE001
        log.exception("successful_payment handling failed")
        sp = msg.successful_payment
        await svc.notifier.notify_admins(
            f"🚨 Ошибка обработки Stars-платежа! payload={sp.invoice_payload} "
            f"charge=<code>{sp.telegram_payment_charge_id}</code> tg={msg.from_user.id}")
