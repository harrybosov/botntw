"""Конфигурация FLUX VPN. Все секреты читаются ТОЛЬКО из переменных окружения / .env."""
from __future__ import annotations

import ipaddress
import os
import re
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent


class ConfigError(RuntimeError):
    pass


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default).strip()


def _clean_url(url: str) -> str:
    """'https:https://host/x/' → 'https://host/x'; добавляет https://, если схемы нет."""
    url = re.sub(r"^(https?:)+(?=https?://)", "", url.strip()).rstrip("/")
    if url and "://" not in url:
        url = "https://" + url
    return url


def _is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def _bool(name: str, default: bool) -> bool:
    v = _env(name)
    return default if v == "" else v.lower() in {"1", "true", "yes", "on"}


def _int(name: str, default: int) -> int:
    v = _env(name)
    if not v:
        return default
    try:
        return int(v)
    except ValueError as e:
        raise ConfigError(f"{name} должен быть целым числом") from e


def _int_list(name: str, default: str = "") -> list[int]:
    raw = _env(name, default)
    out: list[int] = []
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.append(int(part))
        except ValueError as e:
            raise ConfigError(f"{name}: '{part}' не является числом") from e
    return out


class NodeConfig(BaseModel):
    key: str
    country: str = ""
    base_url: str = ""
    username: str = ""
    password: str = Field(default="", repr=False)
    api_token: str = Field(default="", repr=False)
    api_mode: str = "auto"
    public_host: str = ""
    inbound_ids: list[int] = Field(default_factory=list)
    verify_ssl: bool = True


class Settings(BaseModel):
    bot_token: str = Field(default="", repr=False)
    admin_ids: list[int] = Field(default_factory=list)
    env: str = "production"
    timezone: str = "Europe/Moscow"
    support_username: str = ""

    database_path: str = "data/flux.db"
    backup_dir: str = "backups"
    backup_keep: int = 14
    backup_interval_hours: int = 24
    log_level: str = "INFO"
    log_file: str = "logs/flux.log"

    vpn_mode: str = "mock"
    vpn_limit_ip: int = 0
    nodes: list[NodeConfig] = Field(default_factory=list)

    order_ttl_stars_min: int = 60
    order_ttl_crypto_min: int = 60
    order_ttl_donate_min: int = 180
    order_ttl_cispay_min: int = 60

    stars_enabled: bool = True
    cispay_shop_id: str = ""
    cispay_api_key: str = Field(default="", repr=False)
    cispay_allow_sandbox: bool = False

    cryptobot_token: str = Field(default="", repr=False)
    cryptobot_network: str = "main"
    cryptobot_assets: str = "USDT,TON,BTC,ETH,LTC,TRX,USDC"
    cryptobot_webhook_secret: str = Field(default="", repr=False)
    sub_feed_host: str = "127.0.0.1"
    sub_feed_port: int = 8080

    donatealerts_url: str = ""
    donatealerts_client_id: str = ""
    donatealerts_client_secret: str = Field(default="", repr=False)
    donatealerts_token_file: str = "data/donatealerts_token.json"
    donatealerts_poll_seconds: int = 20

    public_url: str = ""
    required_channel: str = "@flux_vpnofficial"
    trial_days: int = 1
    xui_sub_url: str = ""
    referral_default_bonus_days: int = 3
    allow_manual_extend: bool = False

    # --- helpers ---
    def is_admin(self, tg_id: int | None) -> bool:
        return tg_id is not None and tg_id in self.admin_ids

    @property
    def cispay_enabled(self) -> bool:
        return bool(self.cispay_shop_id and self.cispay_api_key)

    @property
    def cryptobot_enabled(self) -> bool:
        return bool(self.cryptobot_token)

    @property
    def donatealerts_enabled(self) -> bool:
        return bool(self.donatealerts_url)

    @property
    def donatealerts_api_enabled(self) -> bool:
        return bool(self.donatealerts_client_id and self.donatealerts_client_secret)

    def secrets(self) -> list[str]:
        vals = [self.bot_token, self.cryptobot_token, self.cryptobot_webhook_secret,
                self.donatealerts_client_secret, self.cispay_api_key]
        vals += [n.password for n in self.nodes] + [n.api_token for n in self.nodes]
        return [v for v in vals if v]

    @classmethod
    def load(cls, env_file: str | None = None) -> "Settings":
        load_dotenv(env_file or BASE_DIR / ".env")
        mode = _env("VPN_MODE", "mock").lower()
        if mode not in {"mock", "xui"}:
            raise ConfigError("VPN_MODE должен быть mock или xui")

        nodes: list[NodeConfig] = []
        shared_count: dict[str, int] = {}          # сколько узлов уже сидит на той же панели
        for key in [k.strip().upper() for k in _env("VPN_NODES", "DE,US").split(",") if k.strip()]:
            p = f"XUI_{key}_"

            def pick(name: str, default: str = "", _p: str = p) -> str:
                """Сначала переменная узла (XUI_DE_URL), иначе общая (XUI_URL)."""
                return _env(_p + name) or _env("XUI_" + name) or default

            url = _clean_url(pick("URL"))
            host = urlparse(url).hostname or ""
            verify_raw = pick("VERIFY_SSL")
            verify = (verify_raw.lower() in {"1", "true", "yes", "on"} if verify_raw
                      else not _is_ip(host))       # по голому IP сертификат обычно самоподписанный
            idx = shared_count.get(url, 0)
            shared_count[url] = idx + 1
            ids = _int_list(p + "INBOUNDS") or [3 * idx + 1, 3 * idx + 2, 3 * idx + 3]
            node = NodeConfig(
                key=key, country=pick("COUNTRY", key).upper(), base_url=url,
                username=pick("USERNAME"), password=pick("PASSWORD"), api_token=pick("API_TOKEN"), api_mode=pick("API", "auto").lower(),
                public_host=pick("HOST", host), inbound_ids=ids, verify_ssl=verify,
            )
            if mode == "xui":
                need = [("URL", node.base_url)]
                if not node.api_token:
                    need += [("USERNAME", node.username), ("PASSWORD", node.password)]
                missing = [n for n, v in need if not v]
                if missing:
                    raise ConfigError(f"Узел {key}: не заданы {', '.join('XUI_' + m for m in missing)} "
                                      f"(или XUI_{key}_{missing[0]})")
            nodes.append(node)

        s = cls(
            bot_token=_env("BOT_TOKEN"),
            admin_ids=_int_list("ADMIN_IDS"),
            env=_env("ENV", "production").lower(),
            timezone=_env("TIMEZONE", "Europe/Moscow"),
            support_username=_env("SUPPORT_USERNAME").lstrip("@"),
            database_path=_env("DATABASE_PATH", "data/flux.db"),
            backup_dir=_env("BACKUP_DIR", "backups"),
            backup_keep=_int("BACKUP_KEEP", 14),
            backup_interval_hours=_int("BACKUP_INTERVAL_HOURS", 24),
            log_level=_env("LOG_LEVEL", "INFO").upper(),
            log_file=_env("LOG_FILE", "logs/flux.log"),
            vpn_mode=mode,
            vpn_limit_ip=_int("VPN_LIMIT_IP", 0),
            nodes=nodes,
            order_ttl_stars_min=_int("ORDER_TTL_STARS_MIN", 60),
            order_ttl_crypto_min=_int("ORDER_TTL_CRYPTO_MIN", 60),
            order_ttl_donate_min=_int("ORDER_TTL_DONATE_MIN", 180),
            order_ttl_cispay_min=_int("ORDER_TTL_CISPAY_MIN", 60),
            stars_enabled=_bool("STARS_ENABLED", True),
            cispay_shop_id=_env("CISPAY_SHOP_ID"),
            cispay_api_key=_env("CISPAY_API_KEY"),
            cispay_allow_sandbox=_bool("CISPAY_ALLOW_SANDBOX", False),
            cryptobot_token=_env("CRYPTOBOT_TOKEN"),
            cryptobot_network=_env("CRYPTOBOT_NETWORK", "main").lower(),
            cryptobot_assets=_env("CRYPTOBOT_ASSETS", "USDT,TON,BTC,ETH,LTC,TRX,USDC"),
            cryptobot_webhook_secret=_env("CRYPTOBOT_WEBHOOK_SECRET"),
            sub_feed_host=_env("SUB_FEED_HOST", _env("WEBHOOK_HOST", "127.0.0.1")),
            sub_feed_port=_int("SUB_FEED_PORT", _int("WEBHOOK_PORT", 8080)),
            donatealerts_url=_env("DONATEALERTS_URL"),
            donatealerts_client_id=_env("DONATEALERTS_CLIENT_ID"),
            donatealerts_client_secret=_env("DONATEALERTS_CLIENT_SECRET"),
            donatealerts_token_file=_env("DONATEALERTS_TOKEN_FILE", "data/donatealerts_token.json"),
            donatealerts_poll_seconds=_int("DONATEALERTS_POLL_SECONDS", 20),
            public_url=_env("PUBLIC_URL").rstrip("/"),
            required_channel=_env("REQUIRED_CHANNEL", "@flux_vpnofficial"),
            trial_days=_int("TRIAL_DAYS", 1),
            xui_sub_url=_clean_url(_env("XUI_SUB_URL")),
            referral_default_bonus_days=_int("REFERRAL_DEFAULT_BONUS_DAYS", 3),
            allow_manual_extend=_bool("ALLOW_MANUAL_EXTEND", False),
        )
        if s.cryptobot_network not in {"main", "test"}:
            raise ConfigError("CRYPTOBOT_NETWORK должен быть main или test")
        return s

    def validate_for_run(self) -> None:
        if not self.bot_token:
            raise ConfigError("BOT_TOKEN не задан")
        if not self.admin_ids:
            raise ConfigError("ADMIN_IDS не задан (нужен хотя бы один администратор)")
        if self.vpn_mode == "xui" and not self.nodes:
            raise ConfigError("VPN_MODE=xui, но VPN_NODES пуст")


def abs_path(p: str) -> Path:
    path = Path(p)
    return path if path.is_absolute() else BASE_DIR / path
