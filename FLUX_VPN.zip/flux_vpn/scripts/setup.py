"""Мастер настройки FLUX VPN:  python -m scripts.setup
Задаёт вопросы по-русски, сам находит inbound'ы в панелях 3X-UI и записывает .env.
Уже заданные значения можно оставлять, нажимая Enter."""
from __future__ import annotations

import asyncio
import getpass
import re
import secrets
import sys
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent
ENV, EXAMPLE = ROOT / ".env", ROOT / ".env.example"


def set_env(text: str, key: str, value: str) -> str:
    line = f"{key}={value}"
    pat = re.compile(rf"^{re.escape(key)}=.*$", re.M)
    return pat.sub(lambda _: line, text, count=1) if pat.search(text) else text.rstrip("\n") + f"\n{line}\n"


def get_env(text: str, key: str) -> str:
    m = re.search(rf"^{re.escape(key)}=(.*)$", text, re.M)
    val = m.group(1).strip() if m else ""
    return "" if "example.com" in val else val      # плейсхолдеры из .env.example за значения не считаем


def ask(prompt: str, default: str = "", secret: bool = False) -> str:
    shown = " [уже задано, Enter — оставить]" if (secret and default) else (f" [{default}]" if default else "")
    raw = (getpass.getpass if secret else input)(f"{prompt}{shown}: ").strip()
    return raw or default


def yes(prompt: str, default: bool = True) -> bool:
    raw = input(f"{prompt} [{'Д/н' if default else 'д/Н'}]: ").strip().lower()
    return default if not raw else raw in ("д", "да", "y", "yes")


async def list_inbounds(url: str, user: str, pw: str, verify: bool, token: str = "") -> list[dict]:
    from vpn.xui_adapter import XuiAdapter
    node = SimpleNamespace(key="SETUP", base_url=url, username=user, password=pw, public_host="",
                           verify_ssl=verify, country="", inbound_ids=[], api_token=token)
    a = XuiAdapter(node)
    try:
        return await a._call("GET", "/panel/api/inbounds/list") or []
    finally:
        await a.close()


def configure_node(env: str, key: str, title: str, reuse: dict | None) -> tuple[str, dict]:
    print(f"\n=== {title} ===")
    p = f"XUI_{key}_"
    if reuse:
        url, user, pw, verify = reuse["url"], reuse["user"], reuse["pw"], reuse["verify"]
        print("Используем ту же панель, что и для первой страны.")
    else:
        url = ask("Адрес панели (как в браузере, вместе с секретным путём, без / в конце)",
                  get_env(env, p + "URL")).rstrip("/")
        user = ask("Логин панели", get_env(env, p + "USERNAME"))
        pw = ask("Пароль панели", get_env(env, p + "PASSWORD"), secret=True)
        verify = True
    inbounds: list[dict] = []
    while True:
        try:
            inbounds = asyncio.run(list_inbounds(url, user, pw, verify))
            break
        except Exception as e:  # noqa: BLE001
            print(f"  Не получилось подключиться: {e}")
            if verify and url.startswith("https") and yes("  Сертификат самоподписанный? Отключить проверку SSL"):
                verify = False
                continue
            if yes("  Ввести данные заново"):
                url = ask("Адрес панели", url).rstrip("/")
                user = ask("Логин", user)
                pw = ask("Пароль", pw, secret=True)
                verify = True
                continue
            break
    ids = ""
    if inbounds:
        print("  Найдены inbound'ы:")
        for ib in inbounds:
            print(f"    ID {ib.get('id')}: {ib.get('remark') or '—'} · {ib.get('protocol')} · порт {ib.get('port')}")
        default = ",".join(str(i["id"]) for i in inbounds) if len(inbounds) == 3 else get_env(env, p + "INBOUNDS")
        ids = ask("  Какие 3 ID использовать для этой страны (через запятую)", default)
    else:
        ids = ask("  ID трёх inbound'ов через запятую", get_env(env, p + "INBOUNDS") or "1,2,3")
    host_default = get_env(env, p + "HOST") or (urlparse(url).hostname or "")
    host = ask("  Домен или IP VPN-сервера для клиентских ссылок", host_default)
    for k, v in (("URL", url), ("USERNAME", user), ("PASSWORD", pw), ("HOST", host),
                 ("INBOUNDS", ids.replace(" ", "")), ("VERIFY_SSL", "true" if verify else "false")):
        env = set_env(env, p + k, v)
    return env, {"url": url, "user": user, "pw": pw, "verify": verify}


def main() -> None:
    env = (ENV if ENV.exists() else EXAMPLE).read_text(encoding="utf-8")
    print("⚡ Мастер настройки FLUX VPN. Enter — оставить значение в [скобках].\n")
    env = set_env(env, "BOT_TOKEN", ask("Токен бота (из @BotFather)", get_env(env, "BOT_TOKEN"), secret=True))
    env = set_env(env, "ADMIN_IDS", ask("Ваш Telegram ID (узнать: бот @userinfobot), несколько — через запятую",
                                        get_env(env, "ADMIN_IDS")))
    env = set_env(env, "SUPPORT_USERNAME", ask("Username поддержки без @ (можно пропустить)",
                                               get_env(env, "SUPPORT_USERNAME")))

    print("\nРежим VPN:\n  1 — рабочий (подключить 3X-UI, выдаются настоящие ключи)\n  2 — тестовый (заглушки вместо ключей, только чтобы посмотреть меню)")
    if ask("Выберите 1 или 2", "1") == "1":
        env = set_env(env, "VPN_MODE", "xui")
        env, shared = configure_node(env, "DE", "🇩🇪 Германия", None)
        same = yes("\n🇺🇸 США на той же панели, что и Германия", False)
        env, _ = configure_node(env, "US", "🇺🇸 США", shared if same else None)
    else:
        env = set_env(env, "VPN_MODE", "mock")

    print("\n=== Оплата ===")
    print("⭐ Telegram Stars включены (цены задаются в админ-панели бота).")
    env = set_env(env, "STARS_ENABLED", "true")
    env = set_env(env, "CISPAY_SHOP_ID", ask("cisPay Shop ID (UUID из настроек магазина)",
                                              get_env(env, "CISPAY_SHOP_ID")))
    env = set_env(env, "CISPAY_API_KEY", ask("cisPay API Key (cis_sec_...)", 
                                              get_env(env, "CISPAY_API_KEY"), secret=True))
    env = set_env(env, "CISPAY_ALLOW_SANDBOX", "false")
    print("\n=== Единая ссылка VPN-подписки (необязательно; к оплате не относится) ===")
    print("Домен с HTTPS нужен только для одной короткой ссылки на все VPN-серверы. Без него бот выдаёт ключи списком.")
    env = set_env(env, "PUBLIC_URL", ask("Адрес, например https://bot.example.com (Enter — без подписки)",
                                         get_env(env, "PUBLIC_URL")).rstrip("/"))

    ENV.write_text(env, encoding="utf-8")
    ENV.chmod(0o600)
    print(f"\n✅ Готово: {ENV}\nЗапуск: python bot.py   (или systemctl restart flux-vpn)")
    print("Дальше в боте: /admin → Настройки → Тарифы → задайте цену в Stars для каждого тарифа.")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        sys.exit("\nНастройка прервана, .env не изменён.")
