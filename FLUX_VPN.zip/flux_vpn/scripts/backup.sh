#!/usr/bin/env bash
# Ручная/кроновая резервная копия SQLite (безопасно при работающем боте, использует .backup)
set -euo pipefail
cd "$(dirname "$0")/.."
DB="${DATABASE_PATH:-data/flux.db}"
OUT="${BACKUP_DIR:-backups}"
mkdir -p "$OUT"
DEST="$OUT/flux-manual-$(date +%Y%m%d-%H%M%S).db"
sqlite3 "$DB" ".backup '$DEST'"
chmod 600 "$DEST"
ls -1t "$OUT"/flux-manual-*.db | tail -n +15 | xargs -r rm --
echo "OK: $DEST"
