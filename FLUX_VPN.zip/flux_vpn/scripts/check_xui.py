"""Проверка подключения к панелям 3X-UI:  python -m scripts.check_xui
Логинится в каждую панель, читает каждый inbound из конфигурации, показывает протокол/порт.
Ничего не изменяет."""
import asyncio

from config import Settings
from vpn import links
from vpn.base import PanelError
from vpn.xui_adapter import XuiAdapter


async def main() -> int:
    s = Settings.load()
    bad = 0
    for n in s.nodes:
        a = XuiAdapter(n)
        print(f"== {n.key} {n.base_url}")
        try:
            print("  API панели:", "современный (3.x, clients/*)" if await a._is_modern() else "старый (2.x)")
        except PanelError as e:
            print(f"  вход не удался: {e}")
            bad += 1
            await a.close()
            continue
        for pid in n.inbound_ids:
            try:
                ib = await a._get_inbound(pid, fresh=True)
                n_clients = len(links.loads(ib.get("settings")).get("clients", []) or [])
                print(f"  inbound {pid}: {links.protocol_label(ib)} порт {ib.get('port')} клиентов {n_clients} — OK")
            except PanelError as e:
                bad += 1
                print(f"  inbound {pid}: ОШИБКА {e}")
        await a.close()
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
