import asyncio
import logging

from aiogram import F, Router
from aiogram.exceptions import TelegramAPIError, TelegramForbiddenError, TelegramRetryAfter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from admin import AdminFilter, AdmStates
from keyboards import back, btn, kb
from utils.ui import render

log = logging.getLogger(__name__)
router = Router(name="admin_broadcasts")
router.message.filter(AdminFilter())
router.callback_query.filter(AdminFilter())
_running = False


@router.callback_query(F.data == "adm:bc")
async def bc_start(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdmStates.bc_text)
    await render(cb, "📢 <b>Рассылка</b>\n\nОтправьте текст объявления (до 4000 символов, без разметки).",
                 kb([[back("adm", "Отмена")]]))


@router.message(AdmStates.bc_text, F.text)
async def bc_text(msg: Message, state: FSMContext, svc):
    if len(msg.text) > 4000:
        return await msg.answer("Слишком длинно (максимум 4000 символов).")
    await state.update_data(text=msg.text)
    await state.set_state(AdmStates.bc_confirm)
    total = len(await svc.users.broadcast_targets())
    await msg.answer("👁 <b>Предпросмотр</b> (так увидят пользователи):")
    await msg.answer(msg.text, parse_mode=None)
    await msg.answer(f"Получателей: <b>{total}</b>. Отправить?",
                     reply_markup=kb([[btn("✅ Отправить", "adm:bc_go", style="success"),
                                       btn("🚫 Отмена", "adm", style="danger")]]))


async def _send_all(svc, text: str, admin_id: int) -> None:
    global _running
    sent = failed = blocked = 0
    try:
        for tg_id in await svc.users.broadcast_targets():
            for attempt in (1, 2):
                try:
                    await svc.bot.send_message(tg_id, text, parse_mode=None)
                    sent += 1
                    break
                except TelegramForbiddenError:
                    blocked += 1
                    await svc.users.mark_bot_blocked(tg_id)
                    break
                except TelegramRetryAfter as e:
                    await asyncio.sleep(e.retry_after + 0.5)
                    if attempt == 2:
                        failed += 1
                except TelegramAPIError as e:
                    log.warning("broadcast to %s failed: %s", tg_id, e)
                    failed += 1
                    break
            await asyncio.sleep(0.05)          # ≈20 сообщений/с — ниже лимитов Telegram
    finally:
        _running = False
    await svc.admin_log(admin_id, "broadcast", "", f"sent={sent} blocked={blocked} failed={failed}")
    await svc.notifier.send(admin_id, f"📢 Рассылка завершена\nДоставлено: {sent}\nЗаблокировали бота: {blocked}\n"
                                      f"Ошибок: {failed}")


@router.callback_query(F.data == "adm:bc_go")
async def bc_go(cb: CallbackQuery, state: FSMContext, svc):
    global _running
    data = await state.get_data()
    text = data.get("text")
    if not text:
        return await render(cb, "Текст не найден, начните заново.", kb([[back("adm")]]))
    if _running:
        return await cb.answer("Рассылка уже идёт", show_alert=True)
    _running = True
    await state.clear()
    asyncio.create_task(_send_all(svc, text, cb.from_user.id))
    await render(cb, "🚀 Рассылка запущена. По завершении пришлю отчёт.", kb([[back("adm")]]))
