from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from admin import AdminFilter, AdmStates
from keyboards import back, btn, kb
from models import PROVIDER_TITLES, Provider
from services.referrals import REF_BONUS_KEY
from utils import texts
from utils.ui import alert, render

router = Router(name="admin_settings")
router.message.filter(AdminFilter())
router.callback_query.filter(AdminFilter())
E = texts.E
FIELDS = {"price": "цену в рублях (целое число)", "days": "продолжительность в днях (целое число)",
          "name": "новое название тарифа", "stars": "цену в Stars (целое число, 0 — убрать цену)"}


@router.callback_query(F.data == "adm:set")
async def settings_menu(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await render(cb, "⚙️ <b>Настройки</b>", kb([
        [btn("📦 Тарифы и цены", "adm:plans")], [btn("🎁 Реферальный бонус", "adm:refbonus")],
        [btn("🔌 Статус интеграций", "adm:status")], [btn("💾 Резервная копия БД", "adm:backup")],
        [back("adm")]]))


@router.callback_query(F.data == "adm:plans")
async def plans(cb: CallbackQuery, svc):
    rows = []
    for p in await svc.plans.list_all():
        stars = await svc.plans.stars_price(p["id"])
        rows.append([btn(f"{'🟢' if p['is_active'] else '⚪️'} {p['name']} · {p['price_rub']} ₽ · {p['days']} дн. · "
                         f"{str(stars) + '⭐' if stars else 'Stars: —'}", f"adm:pe:{p['id']}")])
    rows.append([back("adm:set")])
    await render(cb, "📦 <b>Тарифы</b>\n\nЦена в Stars задаётся вручную — курс не рассчитывается автоматически. "
                     "Пока цена не задана, оплата Stars для тарифа недоступна.", kb(rows))


@router.callback_query(F.data.startswith("adm:pe:"))
async def plan_edit(cb: CallbackQuery, svc, state: FSMContext):
    await state.clear()
    pid = cb.data.split(":")[2]
    p = await svc.plans.get(pid)
    stars = await svc.plans.stars_price(pid)
    await render(cb, f"📦 <b>{E(p['name'])}</b>\n\nЦена: {p['price_rub']} ₽\nСрок: {texts.fmt_days(p['days'])}\n"
                     f"Stars: {stars or '—'}\nСтатус: {'🟢 активен' if p['is_active'] else '⚪️ скрыт'}",
                 kb([[btn("✏️ Цена ₽", f"adm:pf:{pid}:price"), btn("🗓 Дни", f"adm:pf:{pid}:days")],
                     [btn("✏️ Название", f"adm:pf:{pid}:name"), btn("⭐ Цена Stars", f"adm:pf:{pid}:stars")],
                     [btn("👁 Скрыть/показать", f"adm:pt:{pid}")], [back("adm:plans")]]))


@router.callback_query(F.data.startswith("adm:pt:"))
async def plan_toggle(cb: CallbackQuery, svc, state: FSMContext):
    pid = cb.data.split(":")[2]
    p = await svc.plans.get(pid)
    await svc.plans.update(pid, is_active=not p["is_active"])
    await svc.admin_log(cb.from_user.id, "plan_toggle", pid)
    await plan_edit(cb, svc, state)


@router.callback_query(F.data.startswith("adm:pf:"))
async def plan_field(cb: CallbackQuery, state: FSMContext):
    _, _, pid, field = cb.data.split(":")
    await state.set_state(AdmStates.plan_value)
    await state.update_data(pid=pid, field=field)
    await render(cb, f"Отправьте {FIELDS[field]}.", kb([[back(f"adm:pe:{pid}", "Отмена")]]))


@router.message(AdmStates.plan_value, F.text)
async def plan_value(msg: Message, state: FSMContext, svc):
    d = await state.get_data()
    pid, field, raw = d["pid"], d["field"], msg.text.strip()
    try:
        if field == "name":
            if not 1 <= len(raw) <= 40:
                raise ValueError("Название: 1–40 символов")
            await svc.plans.update(pid, name=raw)
        else:
            n = int(raw)
            if field == "stars":
                if n < 0:
                    raise ValueError("Не может быть отрицательным")
                await svc.plans.set_stars_price(pid, n or None)
            elif n <= 0:
                raise ValueError("Число должно быть больше нуля")
            elif field == "price":
                await svc.plans.update(pid, price_rub=n)
            else:
                await svc.plans.update(pid, days=n)
    except ValueError as e:
        return await msg.answer(f"❌ {e}")
    await state.clear()
    await svc.admin_log(msg.from_user.id, "plan_edit", pid, f"{field}={raw}")
    await msg.answer("✅ Сохранено", reply_markup=kb([[back(f"adm:pe:{pid}", "К тарифу")]]))


@router.callback_query(F.data == "adm:refbonus")
async def ref_bonus(cb: CallbackQuery, svc, state: FSMContext):
    cur = await svc.kv.get_int(REF_BONUS_KEY, 0)
    await state.set_state(AdmStates.ref_bonus)
    await render(cb, f"🎁 Текущий бонус за приглашение: <b>{texts.fmt_days(cur)}</b>.\n"
                     "Отправьте новое число дней (0 — отключить).", kb([[back("adm:set", "Отмена")]]))


@router.message(AdmStates.ref_bonus, F.text)
async def ref_bonus_msg(msg: Message, state: FSMContext, svc):
    raw = msg.text.strip()
    if not raw.isdigit() or int(raw) > 3650:
        return await msg.answer("Нужно целое число от 0 до 3650.")
    await svc.kv.set(REF_BONUS_KEY, raw)
    await state.clear()
    await svc.admin_log(msg.from_user.id, "ref_bonus", raw)
    await msg.answer("✅ Сохранено", reply_markup=kb([[back("adm:set", "В настройки")]]))


@router.callback_query(F.data == "adm:status")
async def status(cb: CallbackQuery, svc):
    s = svc.settings
    lines = ["🔌 <b>Интеграции</b>", "",
             f"VPN: <b>{s.vpn_mode}</b>" + (" (тестовые заглушки!)" if s.vpn_mode == "mock" else ""),
             f"Узлы: {', '.join(f'{n.key}×{len(n.inbound_ids)}' for n in s.nodes)}",
             f"{PROVIDER_TITLES[Provider.STARS]}: {'вкл' if svc.stars else 'выкл'}",
             f"{PROVIDER_TITLES[Provider.CISPAY]}: {'вкл' if svc.cispay else 'выкл'}",
             f"Ссылка подписки: {s.xui_sub_url or s.public_url or 'не настроена'}",
             f"Обязательный канал: {s.required_channel or 'выключен'} · пробный период: {s.trial_days} дн.",
             f"Ручное продление админом: {'вкл' if s.allow_manual_extend else 'выкл'}"]
    dirty = await svc.db.fetchone("SELECT COUNT(*) c FROM subscriptions WHERE vpn_dirty=1")
    lines.append(f"Подписок, ожидающих синхронизации с VPN: {dirty['c']}")
    await render(cb, "\n".join(lines), kb([[back("adm:set")]]))


@router.callback_query(F.data == "adm:backup")
async def backup(cb: CallbackQuery, svc):
    from config import abs_path
    path = await svc.db.backup(abs_path(svc.settings.backup_dir), keep=svc.settings.backup_keep)
    await svc.admin_log(cb.from_user.id, "backup", str(path))
    await alert(cb, f"Копия создана: {path.name}" if path else "Копия недоступна для этой БД")
