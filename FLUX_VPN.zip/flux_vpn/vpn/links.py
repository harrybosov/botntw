"""Построение клиентских ссылок из данных inbound панели 3X-UI (чистые функции, без сети)."""
from __future__ import annotations

import base64
import json
from urllib.parse import quote, urlencode

from vpn.base import UnsupportedProtocol


def loads(x) -> dict:
    if isinstance(x, dict):
        return x
    if not x:
        return {}
    try:
        v = json.loads(x)
        return v if isinstance(v, dict) else {}
    except (TypeError, ValueError):
        return {}


def protocol_label(inbound: dict) -> str:
    proto = (inbound.get("protocol") or "").lower()
    stream = loads(inbound.get("streamSettings"))
    net = (stream.get("network") or "tcp").lower()
    sec = (stream.get("security") or "none").lower()
    names = {"vless": "VLESS", "vmess": "VMess", "trojan": "Trojan", "shadowsocks": "Shadowsocks"}
    base = names.get(proto, proto.upper() or "?")
    if proto == "shadowsocks":
        return base
    extra = []
    if sec in ("reality", "tls"):
        extra.append(sec.upper())
    if net != "tcp":
        extra.append(net.upper())
    return base + (" + " + " + ".join(extra) if extra else "")


def _transport_params(stream: dict) -> dict:
    net = (stream.get("network") or "tcp").lower()
    p: dict = {"type": net}
    if net == "tcp":
        header = (stream.get("tcpSettings") or {}).get("header") or {}
        if header.get("type") == "http":
            p["headerType"] = "http"
            req = header.get("request") or {}
            hosts = (req.get("headers") or {}).get("Host")
            if hosts:
                p["host"] = hosts[0] if isinstance(hosts, list) else hosts
            paths = req.get("path")
            if paths:
                p["path"] = paths[0] if isinstance(paths, list) else paths
    elif net == "ws":
        ws = stream.get("wsSettings") or {}
        p["path"] = ws.get("path") or "/"
        host = ws.get("host") or (ws.get("headers") or {}).get("Host")
        if host:
            p["host"] = host
    elif net == "grpc":
        g = stream.get("grpcSettings") or {}
        p["serviceName"] = g.get("serviceName") or ""
        if g.get("authority"):
            p["authority"] = g["authority"]
        if g.get("multiMode"):
            p["mode"] = "multi"
    elif net in ("httpupgrade", "xhttp", "splithttp"):
        s = stream.get(f"{net}Settings") or {}
        p["path"] = s.get("path") or "/"
        if s.get("host"):
            p["host"] = s["host"]
        if net == "xhttp" and s.get("mode"):
            p["mode"] = s["mode"]
    return p


def _security_params(stream: dict) -> dict:
    sec = (stream.get("security") or "none").lower()
    p: dict = {"security": sec}
    if sec == "tls":
        tls = stream.get("tlsSettings") or {}
        inner = tls.get("settings") or {}
        sni = tls.get("serverName") or inner.get("serverName")
        if sni:
            p["sni"] = sni
        fp = inner.get("fingerprint") or tls.get("fingerprint")
        if fp:
            p["fp"] = fp
        alpn = tls.get("alpn")
        if alpn:
            p["alpn"] = ",".join(alpn) if isinstance(alpn, list) else alpn
    elif sec == "reality":
        r = stream.get("realitySettings") or {}
        inner = r.get("settings") or {}
        names = r.get("serverNames") or []
        sni = inner.get("serverName") or (names[0] if names else "")
        if sni:
            p["sni"] = sni
        p["fp"] = inner.get("fingerprint") or "chrome"
        if inner.get("publicKey"):
            p["pbk"] = inner["publicKey"]
        sids = r.get("shortIds") or []
        if sids:
            p["sid"] = sids[0]
        p["spx"] = inner.get("spiderX") or "/"
    return p


def build_link(inbound: dict, host: str, client: dict, remark: str) -> str:
    proto = (inbound.get("protocol") or "").lower()
    port = inbound.get("port")
    stream = loads(inbound.get("streamSettings"))
    tag = quote(remark, safe="")
    if proto == "vless":
        params = {"type": "tcp", "encryption": "none"}
        params.update(_transport_params(stream))
        params.update(_security_params(stream))
        if client.get("flow"):
            params["flow"] = client["flow"]
        return f"vless://{client['id']}@{host}:{port}?{urlencode(params, quote_via=quote)}#{tag}"
    if proto == "vmess":
        t = _transport_params(stream)
        s = _security_params(stream)
        obj = {"v": "2", "ps": remark, "add": host, "port": str(port), "id": client["id"], "aid": "0",
               "scy": client.get("security") or "auto", "net": t.get("type", "tcp"),
               "type": t.get("headerType", "none"), "host": t.get("host", ""), "path": t.get("path", ""),
               "tls": "tls" if s["security"] == "tls" else "", "sni": s.get("sni", ""),
               "alpn": s.get("alpn", ""), "fp": s.get("fp", "")}
        raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode()
        return "vmess://" + base64.b64encode(raw).decode()
    if proto == "trojan":
        params = {"type": "tcp"}
        params.update(_transport_params(stream))
        params.update(_security_params(stream))
        return f"trojan://{quote(client['password'], safe='')}@{host}:{port}?{urlencode(params, quote_via=quote)}#{tag}"
    if proto == "shadowsocks":
        settings = loads(inbound.get("settings"))
        method = client.get("method") or settings.get("method") or ""
        pw = client.get("password", "")
        if method.startswith("2022-") and settings.get("password"):
            pw = f"{settings['password']}:{pw}"
        userinfo = base64.urlsafe_b64encode(f"{method}:{pw}".encode()).decode().rstrip("=")
        params = _transport_params(stream)
        q = f"?{urlencode(params, quote_via=quote)}" if params.get("type", "tcp") != "tcp" else ""
        return f"ss://{userinfo}@{host}:{port}{q}#{tag}"
    raise UnsupportedProtocol(f"Протокол '{proto}' не поддерживается генератором ссылок")
