"""Тестовый адаптер-заглушка (VPN_MODE=mock). Ссылки НЕ являются рабочими конфигурациями."""
from __future__ import annotations

import uuid

from vpn.base import ClientState, LinkInfo, PanelAdapter

_MOCK_PROTOCOLS = ["VLESS + REALITY", "VLESS + TLS", "VLESS + WS"]


class MockAdapter(PanelAdapter):
    def __init__(self, key: str, fail: bool = False):
        self.key = key
        self.fail = fail                      # для тестов: имитация недоступной панели
        self.clients: dict[tuple[int, str], dict] = {}
        self.calls: list[tuple] = []

    async def ensure_client(self, panel_inbound_id, email, secret, expiry_ts, enabled, comment="", sub_id=""):
        self.calls.append(("ensure", panel_inbound_id, email, expiry_ts, enabled, sub_id))
        if self.fail:
            from vpn.base import PanelConnectionError
            raise PanelConnectionError("mock: panel unavailable")
        k = (panel_inbound_id, email)
        created = k not in self.clients
        if created:
            self.clients[k] = {"secret": secret or str(uuid.uuid4())}
        c = self.clients[k]
        c.update(expiry_ts=expiry_ts, enabled=enabled)
        return ClientState(c["secret"], "vless", self._label(panel_inbound_id), expiry_ts, enabled, created)

    async def get_client(self, panel_inbound_id, email):
        c = self.clients.get((panel_inbound_id, email))
        if not c:
            return None
        return ClientState(c["secret"], "vless", self._label(panel_inbound_id), c["expiry_ts"], c["enabled"])

    def _label(self, pid: int) -> str:
        return _MOCK_PROTOCOLS[(pid - 1) % len(_MOCK_PROTOCOLS)]

    async def build_link(self, panel_inbound_id, email, secret, remark):
        return LinkInfo(self._label(panel_inbound_id) + " (заглушка)",
                        f"flux-demo://NOT-A-REAL-CONFIG/{self.key}/{panel_inbound_id}?note=test-placeholder",
                        is_placeholder=True)
