"""Базовые типы и интерфейс адаптера VPN-панели."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


class PanelError(Exception):
    """Любая ошибка панели (сеть, авторизация, ответ success=false, неподдерживаемый протокол)."""


class PanelConnectionError(PanelError): ...
class PanelAuthError(PanelError): ...
class UnsupportedProtocol(PanelError): ...


@dataclass
class ClientState:
    secret: str          # uuid (vless/vmess) / password (trojan, shadowsocks)
    protocol: str        # vless / vmess / trojan / shadowsocks
    label: str           # человекочитаемо, напр. "VLESS + REALITY"
    expiry_ts: int
    enabled: bool
    created: bool = False


@dataclass
class LinkInfo:
    protocol_label: str
    link: str
    is_placeholder: bool = False
    title: str = ""


class PanelAdapter(ABC):
    """Один адаптер = одна панель 3X-UI (узел). Германия и США могут быть на разных панелях."""

    key: str

    @abstractmethod
    async def ensure_client(self, panel_inbound_id: int, email: str, secret: str | None,
                            expiry_ts: int, enabled: bool, comment: str = "", sub_id: str = "") -> ClientState:
        """Идемпотентно: создаёт клиента, если его нет (по email), иначе обновляет срок/enable."""

    @abstractmethod
    async def get_client(self, panel_inbound_id: int, email: str) -> ClientState | None: ...

    @abstractmethod
    async def build_link(self, panel_inbound_id: int, email: str, secret: str, remark: str) -> LinkInfo: ...

    async def is_unified(self) -> bool:
        """True, если панель хранит ОДНОГО клиента, привязанного ко многим inbound (3X-UI 3.x)."""
        return False

    async def ensure_user(self, items: list[dict], shared_email: str, expiry_ts: int, enabled: bool,
                          comment: str = "", sub_id: str = "", cleanup_emails=()) -> dict[int, ClientState]:
        """items: [{"pid": inbound_id, "email": ..., "secret": ... | None}]. По умолчанию — клиент на каждый inbound."""
        out: dict[int, ClientState] = {}
        for it in items:
            out[it["pid"]] = await self.ensure_client(it["pid"], it["email"], it.get("secret"), expiry_ts,
                                                      enabled, comment, sub_id)
        return out

    async def user_links(self, shared_email: str) -> list[LinkInfo]:
        """Все ссылки клиента (только для unified-панелей)."""
        return []

    async def close(self) -> None:  # noqa: B027
        pass
