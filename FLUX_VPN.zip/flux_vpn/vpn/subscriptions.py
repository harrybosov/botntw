"""Связка «подписка в БД» ↔ «клиенты в панелях».

Панели 3X-UI 3.x: ОДИН клиент на пользователя (email = flux<TG_ID>), привязанный ко ВСЕМ inbound'ам панели →
одна подписка со всеми серверами. Старые панели 2.x: по клиенту на inbound (общий subId).
"""
from __future__ import annotations

import asyncio
import logging
import secrets
from collections import defaultdict
from dataclasses import dataclass, field

from utils import clock
from vpn.base import PanelError
from vpn.nodes import NodeRegistry, country_meta

log = logging.getLogger(__name__)


@dataclass
class SyncResult:
    ok: bool
    errors: list[str] = field(default_factory=list)
    synced: int = 0


@dataclass
class ConnectionView:
    inbound_id: int
    node_key: str
    country: str
    position: int
    title: str
    protocol_label: str
    link: str | None
    error: str | None = None
    is_placeholder: bool = False


def shared_email(tg_id: int) -> str:
    """Email единого клиента пользователя в панели 3.x."""
    return f"flux{tg_id}"


def client_email(tg_id: int, node_key: str, position: int) -> str:
    """Email клиента на конкретный inbound (старые панели 2.x и прежние версии бота)."""
    return f"flux{tg_id}-{node_key.lower()}{position}"


class VpnManager:
    def __init__(self, db, registry: NodeRegistry):
        self.db = db
        self.registry = registry
        self._locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)

    async def _sub_id(self, user_id: int) -> str:
        """subId клиента = личный токен пользователя → ссылка подписки панели: <XUI_SUB_URL>/<токен>."""
        async with self.db.tx() as t:
            row = await t.fetchone("SELECT sub_token FROM users WHERE id=?", (user_id,))
            if row and row["sub_token"]:
                return row["sub_token"]
            token = secrets.token_hex(16)
            await t.execute("UPDATE users SET sub_token=? WHERE id=?", (token, user_id))
            return token

    def _groups(self, inbounds: list[dict]) -> list[tuple[object, list[dict]]]:
        """Группировка inbound'ов по ПАНЕЛИ (адаптер один на панель), порядок сохраняется."""
        groups: dict[int, tuple[object, list[dict]]] = {}
        for ib in inbounds:
            a = self.registry.adapter(ib["node_key"])
            groups.setdefault(id(a), (a, []))[1].append(ib)
        return list(groups.values())

    async def sync_user(self, user_id: int) -> SyncResult:
        """Идемпотентно приводит клиентов в панелях к состоянию подписки. Не бросает исключений."""
        async with self._locks[user_id]:
            try:
                return await self._sync(user_id)
            except Exception as e:  # noqa: BLE001
                log.exception("sync_user(%s) crashed", user_id)
                return SyncResult(False, [f"internal: {type(e).__name__}"])

    async def _sync(self, user_id: int) -> SyncResult:
        sub = await self.db.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))
        user = await self.db.fetchone("SELECT * FROM users WHERE id=?", (user_id,))
        if not sub or not user:
            return SyncResult(True)
        now = clock.now()
        enabled = sub["status"] == "ACTIVE" and sub["ends_at"] > now
        sub_id = await self._sub_id(user_id)
        tg = user["tg_id"]
        inbounds = await self.registry.active_inbounds()
        existing = {r["inbound_id"]: r for r in await self.db.fetchall(
            "SELECT * FROM vpn_clients WHERE user_id=?", (user_id,))}
        errors: list[str] = []

        async def run_group(adapter, items: list[dict]) -> int:
            node = items[0]["node_key"]
            req = [{"pid": ib["panel_inbound_id"], "email": client_email(tg, ib["node_key"], ib["position"]),
                    "secret": (existing.get(ib["inbound_id"]) or {}).get("secret")} for ib in items]
            try:
                unified = await adapter.is_unified()
                legacy_emails = [r["email"] for r in req]       # прежние клиенты «по одному на сервер»
                legacy_emails += [r["email"] for r in existing.values() if r["email"] != shared_email(tg)]
                states = await adapter.ensure_user(
                    req, shared_email(tg), sub["ends_at"], enabled, comment=f"FLUX tg:{tg}", sub_id=sub_id,
                    cleanup_emails=sorted(set(legacy_emails)) if unified else ())
            except PanelError as e:
                errors.append(f"{node}: {e}")
                return 0
            for ib, r in zip(items, req):
                st = states.get(ib["panel_inbound_id"])
                if st is None:
                    continue
                await self.db.execute(
                    "INSERT INTO vpn_clients(user_id,inbound_id,email,secret,expiry_at,enabled,synced_at) "
                    "VALUES(?,?,?,?,?,?,?) ON CONFLICT(user_id,inbound_id) DO UPDATE SET email=excluded.email, "
                    "secret=excluded.secret, expiry_at=excluded.expiry_at, enabled=excluded.enabled, "
                    "synced_at=excluded.synced_at",
                    (user_id, ib["inbound_id"], shared_email(tg) if unified else r["email"], st.secret,
                     sub["ends_at"], int(st.enabled), clock.now()))
                if st.label and st.label != ib["protocol"]:
                    await self.db.execute("UPDATE vpn_inbounds SET protocol=? WHERE id=?",
                                          (st.label, ib["inbound_id"]))
            return len(states)

        results = await asyncio.gather(*(run_group(a, items) for a, items in self._groups(inbounds)))
        synced = sum(results)
        if errors:
            await self.db.execute("UPDATE subscriptions SET vpn_error=?, updated_at=? WHERE id=?",
                                  ("; ".join(errors)[:500], clock.now(), sub["id"]))
            return SyncResult(False, errors, synced)
        # dirty сбрасываем, только если подписку не меняли во время синхронизации
        await self.db.execute(
            "UPDATE subscriptions SET vpn_dirty=0, vpn_error=NULL WHERE id=? AND ends_at=? AND status=?",
            (sub["id"], sub["ends_at"], sub["status"]))
        return SyncResult(True, [], synced)

    async def connections(self, user_id: int) -> list[ConnectionView]:
        """ВСЕ ссылки подписки пользователя (чужие недоступны по построению). Пусто, если подписка неактивна."""
        sub = await self.db.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user_id,))
        user = await self.db.fetchone("SELECT * FROM users WHERE id=?", (user_id,))
        if not sub or not user or sub["status"] != "ACTIVE" or sub["ends_at"] <= clock.now():
            return []
        clients = {r["inbound_id"]: r for r in await self.db.fetchall(
            "SELECT * FROM vpn_clients WHERE user_id=? AND enabled=1", (user_id,))}
        views: list[ConnectionView] = []
        for adapter, items in self._groups(await self.registry.active_inbounds()):
            try:
                unified = await adapter.is_unified()
            except PanelError as e:
                log.warning("panel unavailable: %s", e)
                views.append(self._err(items[0], "Панель временно недоступна"))
                continue
            if unified:
                if not any(ib["inbound_id"] in clients for ib in items):
                    views.append(self._err(items[0], "Подключение ещё готовится"))
                    continue
                try:
                    infos = await adapter.user_links(shared_email(user["tg_id"]))
                except PanelError as e:
                    log.warning("user_links failed: %s", e)
                    views.append(self._err(items[0], "Панель временно недоступна"))
                    continue
                for i, info in enumerate(infos, 1):
                    views.append(ConnectionView(-(len(views) + 1), items[0]["node_key"], "", i, info.title,
                                                info.protocol_label, info.link, None, info.is_placeholder))
                continue
            for ib in items:                                      # панели 2.x и режим mock: по inbound'у
                flag, ru, en = country_meta(ib["country"])
                c = clients.get(ib["inbound_id"])
                v = ConnectionView(ib["inbound_id"], ib["node_key"], ib["country"], ib["position"],
                                   f"{flag} {ru} — Подключение {ib['position']}", ib["protocol"] or "—", None)
                if c is None:
                    v.error = "Подключение ещё готовится"
                else:
                    try:
                        info = await adapter.build_link(ib["panel_inbound_id"], c["email"], c["secret"],
                                                        f"FLUX {en} {ib['position']}")
                        v.link, v.protocol_label, v.is_placeholder = info.link, info.protocol_label, info.is_placeholder
                    except PanelError as e:
                        log.warning("build_link failed: %s", e)
                        v.error = "Панель временно недоступна"
                views.append(v)
        return views

    @staticmethod
    def _err(ib: dict, text: str) -> ConnectionView:
        return ConnectionView(0, ib["node_key"], ib["country"], 0, "Подключения", "—", None, text)

    async def feed(self, token: str) -> tuple[int, dict, str]:
        """Лента подписки бота (PUBLIC_URL): base64 со списком ссылок. Неактивная подписка → пустой список."""
        import base64
        user = await self.db.fetchone("SELECT * FROM users WHERE sub_token=?", (token or "",))
        if not user or user["is_blocked"]:
            return 404, {}, ""
        sub = await self.db.fetchone("SELECT * FROM subscriptions WHERE user_id=?", (user["id"],))
        links = [v.link for v in await self.connections(user["id"]) if v.link]
        title = base64.b64encode("FLUX VPN".encode()).decode()
        headers = {"profile-title": "base64:" + title, "profile-update-interval": "6",
                   "subscription-userinfo": f"upload=0; download=0; total=0; expire={sub['ends_at'] if sub else 0}",
                   "Cache-Control": "no-store"}
        return 200, headers, base64.b64encode("\n".join(links).encode()).decode()

    async def count_clients(self, user_id: int) -> int:
        r = await self.db.fetchone(
            "SELECT COUNT(*) c FROM vpn_clients c JOIN vpn_inbounds i ON i.id=c.inbound_id "
            "WHERE c.user_id=? AND c.enabled=1 AND i.is_active=1", (user_id,))
        return r["c"]
