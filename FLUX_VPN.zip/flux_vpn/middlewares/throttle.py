from __future__ import annotations

import time

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery


class ThrottleMiddleware(BaseMiddleware):
    """Отбрасывает слишком частые нажатия/сообщения одного пользователя."""

    def __init__(self, interval: float = 0.4):
        self.interval = interval
        self._last: dict[int, float] = {}

    async def __call__(self, handler, event, data):
        u = event.from_user
        if getattr(event, "successful_payment", None) is not None:
            return await handler(event, data)      # платёж никогда не отбрасываем
        if u is not None:
            now = time.monotonic()
            if now - self._last.get(u.id, 0) < self.interval:
                if isinstance(event, CallbackQuery):
                    await event.answer()
                return None
            self._last[u.id] = now
            if len(self._last) > 10000:
                cutoff = now - 60
                self._last = {k: v for k, v in self._last.items() if v > cutoff}
        return await handler(event, data)
