"""Регистрация пользователей, бан, обязательная подписка на канал и выдача пробного периода."""
from __future__ import annotations

import logging

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

log = logging.getLogger("flux")
CHECK_CALLBACK = "channel_subscription_check"


def parse_ref(text: str | None) -> int | None:
    """'/start ref_12345' → 12345."""
    if not text or not text.startswith("/start"):
        return None
    parts = text.split(maxsplit=1)
    if len(parts) == 2 and parts[1].startswith("ref_") and parts[1][4:].isdigit():
        return int(parts[1][4:])
    return None


def channel_url(channel: str) -> str:
    return f"https://t.me/{channel.lstrip('@')}"


def channel_keyboard(channel: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📢 Подписаться на канал", url=channel_url(channel))],
        [InlineKeyboardButton(text="🔄 Проверить подписку", callback_data=CHECK_CALLBACK)],
    ])


def subscription_gate_text() -> str:
    return (
        "👋 Добро пожаловать в <b>FLUX VPN</b>!\n\n"
        "📢 Подпишитесь на наш Telegram-канал, чтобы пользоваться ботом.\n\n"
        "В канале публикуются важные новости, обновления серверов, "
        "информация о работах и специальные предложения.\n\n"
        "После подписки нажмите «🔄 Проверить подписку»."
    )


async def is_channel_member(bot, user_id: int, channel: str) -> bool:
    """Проверяет подписку. Бот должен быть администратором канала."""
    member = await bot.get_chat_member(chat_id=channel, user_id=user_id)
    if member.status in {"creator", "administrator", "member"}:
        return True
    return member.status == "restricted" and bool(getattr(member, "is_member", False))


class UserMiddleware(BaseMiddleware):
    def __init__(self, svc):
        self.svc = svc

    async def __call__(self, handler, event, data):
        u = event.from_user
        if u is None or u.is_bot:
            return await handler(event, data)
        ref = parse_ref(event.text) if isinstance(event, Message) else None
        user, created = await self.svc.users.upsert_from_telegram(
            u.id, u.username, u.first_name, u.last_name, ref)
        data["user"], data["is_new"] = user, created
        data["is_admin"] = self.svc.settings.is_admin(u.id)

        # Платёж Stars нельзя терять даже у заблокированного пользователя.
        paying = isinstance(event, Message) and event.successful_payment is not None
        if user["is_blocked"] and not data["is_admin"] and not paying:
            if isinstance(event, CallbackQuery):
                await event.answer("Доступ к боту ограничен", show_alert=True)
            return None

        # Обязательная подписка на канал (кроме админов, платежей и кнопки «Проверить подписку»).
        channel = self.svc.settings.required_channel
        check_callback = isinstance(event, CallbackQuery) and event.data == CHECK_CALLBACK
        if channel and not data["is_admin"] and not paying and not check_callback:
            try:
                subscribed = await is_channel_member(event.bot, u.id, channel)
            except Exception:  # noqa: BLE001
                log.exception("Не удалось проверить подписку пользователя %s на %s", u.id, channel)
                error_text = ("⚠️ Сейчас не удалось проверить подписку на канал.\n"
                              "Попробуйте ещё раз чуть позже. Если ошибка повторяется, сообщите поддержке.")
                if isinstance(event, Message):
                    await event.answer(error_text, reply_markup=channel_keyboard(channel))
                elif isinstance(event, CallbackQuery):
                    await event.answer("Не удалось проверить подписку. Попробуйте позже.", show_alert=True)
                return None
            if not subscribed:
                if isinstance(event, Message):
                    await event.answer(subscription_gate_text(), reply_markup=channel_keyboard(channel))
                elif isinstance(event, CallbackQuery):
                    await event.answer("Сначала подпишитесь на канал FLUX VPN", show_alert=True)
                    if event.message:
                        await event.message.answer(subscription_gate_text(), reply_markup=channel_keyboard(channel))
                return None

        # Пробный период: один раз каждому, кто прошёл проверки (в том числе давно зарегистрированным).
        granted = False
        if not paying and not check_callback and not user.get("trial_granted_at"):
            try:
                granted = await self.svc.trial.grant(user)
            except Exception:  # noqa: BLE001
                log.exception("Не удалось выдать пробный период user=%s", u.id)
        result = await handler(event, data)
        if granted:
            try:
                await self.svc.trial.notify(user)
            except Exception:  # noqa: BLE001
                log.exception("Не удалось отправить карточку пробного периода user=%s", u.id)
        return result
