"""Перечисления и константы предметной области."""


class OrderStatus:
    PENDING = "PENDING"
    PAID = "PAID"
    EXPIRED = "EXPIRED"
    CANCELLED = "CANCELLED"
    REFUNDED = "REFUNDED"
    ALL = (PENDING, PAID, EXPIRED, CANCELLED, REFUNDED)


class Provider:
    STARS = "STARS"
    CRYPTOBOT = "CRYPTOBOT"
    DONATEALERTS = "DONATEALERTS"
    CISPAY = "CISPAY"
    MANUAL = "MANUAL"  # только как источник платежа (подтверждение админом)
    # Legacy values remain readable for historical orders; runtime exposes only STARS and CISPAY.
    ORDER_PROVIDERS = (STARS, CISPAY)


class SubStatus:
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"


class PaymentStatus:
    PAID = "PAID"
    REFUNDED = "REFUNDED"
    REJECTED = "REJECTED"


CURRENCY_RUB = "RUB"
CURRENCY_STARS = "XTR"

PROVIDER_TITLES = {
    Provider.STARS: "⭐ Telegram Stars",
    Provider.CISPAY: "💳 cisPay",
    Provider.MANUAL: "Ручное подтверждение",
}
