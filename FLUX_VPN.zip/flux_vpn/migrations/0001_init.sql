-- FLUX VPN: начальная схема. Время — unix-секунды (UTC).

CREATE TABLE users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    tg_id         INTEGER NOT NULL UNIQUE,
    username      TEXT,
    first_name    TEXT,
    last_name     TEXT,
    is_blocked    INTEGER NOT NULL DEFAULT 0 CHECK (is_blocked IN (0,1)),   -- бан админом
    bot_blocked   INTEGER NOT NULL DEFAULT 0 CHECK (bot_blocked IN (0,1)),  -- пользователь заблокировал бота
    referrer_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    bonus_days    INTEGER NOT NULL DEFAULT 0 CHECK (bonus_days >= 0),
    created_at    INTEGER NOT NULL,
    last_seen_at  INTEGER
);
CREATE INDEX idx_users_created  ON users(created_at);
CREATE INDEX idx_users_referrer ON users(referrer_id);

CREATE TABLE plans (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    days        INTEGER NOT NULL CHECK (days > 0),
    price_rub   INTEGER NOT NULL CHECK (price_rub > 0),
    is_active   INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    sort_order  INTEGER NOT NULL DEFAULT 0,
    created_at  INTEGER NOT NULL,
    updated_at  INTEGER NOT NULL
);

-- Настраиваемые цены в других валютах (Telegram Stars = 'XTR'). Курс НЕ выдумывается: задаёт админ.
CREATE TABLE plan_prices (
    plan_id   TEXT NOT NULL REFERENCES plans(id) ON DELETE CASCADE,
    currency  TEXT NOT NULL,
    amount    INTEGER NOT NULL CHECK (amount > 0),
    PRIMARY KEY (plan_id, currency)
);

CREATE TABLE subscriptions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    plan_id       TEXT REFERENCES plans(id),
    status        TEXT NOT NULL CHECK (status IN ('ACTIVE','EXPIRED')),
    purchased_at  INTEGER,
    started_at    INTEGER NOT NULL,
    ends_at       INTEGER NOT NULL,
    vpn_dirty     INTEGER NOT NULL DEFAULT 1 CHECK (vpn_dirty IN (0,1)),
    vpn_error     TEXT,
    updated_at    INTEGER NOT NULL
);
CREATE INDEX idx_subs_status_end ON subscriptions(status, ends_at);
CREATE INDEX idx_subs_dirty      ON subscriptions(vpn_dirty);

CREATE TABLE orders (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id    TEXT NOT NULL UNIQUE,
    user_id      INTEGER NOT NULL REFERENCES users(id),
    plan_id      TEXT NOT NULL REFERENCES plans(id),
    plan_name    TEXT NOT NULL,
    days         INTEGER NOT NULL CHECK (days > 0),
    provider     TEXT NOT NULL CHECK (provider IN ('STARS','CRYPTOBOT','DONATEALERTS')),
    amount       INTEGER NOT NULL CHECK (amount > 0),
    currency     TEXT NOT NULL,
    status       TEXT NOT NULL CHECK (status IN ('PENDING','PAID','EXPIRED','CANCELLED','REFUNDED')),
    external_id  TEXT,
    pay_url      TEXT,
    created_at   INTEGER NOT NULL,
    paid_at      INTEGER,
    expires_at   INTEGER NOT NULL
);
CREATE INDEX idx_orders_user     ON orders(user_id, created_at);
CREATE INDEX idx_orders_status   ON orders(status, provider);
CREATE INDEX idx_orders_external ON orders(provider, external_id);

-- Подтверждённые события оплаты. UNIQUE(provider, external_id) = идемпотентность.
CREATE TABLE payments (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id     INTEGER NOT NULL REFERENCES orders(id),
    provider     TEXT NOT NULL CHECK (provider IN ('STARS','CRYPTOBOT','DONATEALERTS','MANUAL')),
    external_id  TEXT NOT NULL,
    amount       INTEGER NOT NULL,
    currency     TEXT NOT NULL,
    status       TEXT NOT NULL CHECK (status IN ('PAID','REFUNDED','REJECTED')),
    note         TEXT,
    created_at   INTEGER NOT NULL,
    UNIQUE (provider, external_id)
);
CREATE INDEX idx_payments_order ON payments(order_id);

CREATE TABLE referrals (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    referrer_id     INTEGER NOT NULL REFERENCES users(id),
    referred_id     INTEGER NOT NULL UNIQUE REFERENCES users(id),
    created_at      INTEGER NOT NULL,
    reward_order_id INTEGER UNIQUE REFERENCES orders(id),
    bonus_days      INTEGER NOT NULL DEFAULT 0,
    rewarded_at     INTEGER,
    CHECK (referrer_id <> referred_id)
);
CREATE INDEX idx_referrals_referrer ON referrals(referrer_id);

CREATE TABLE promo_codes (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    code          TEXT NOT NULL UNIQUE,
    bonus_days    INTEGER NOT NULL CHECK (bonus_days > 0),
    max_uses      INTEGER CHECK (max_uses IS NULL OR max_uses > 0),
    used_count    INTEGER NOT NULL DEFAULT 0,
    expires_at    INTEGER,
    is_active     INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    once_per_user INTEGER NOT NULL DEFAULT 1 CHECK (once_per_user IN (0,1)),
    created_at    INTEGER NOT NULL
);

CREATE TABLE promo_redemptions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    promo_id    INTEGER NOT NULL REFERENCES promo_codes(id) ON DELETE CASCADE,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    redeemed_at INTEGER NOT NULL
);
CREATE INDEX idx_redemptions_promo_user ON promo_redemptions(promo_id, user_id);

CREATE TABLE vpn_nodes (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    key          TEXT NOT NULL UNIQUE,
    country      TEXT NOT NULL,
    public_host  TEXT NOT NULL DEFAULT '',
    is_active    INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    created_at   INTEGER NOT NULL
);

CREATE TABLE vpn_inbounds (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id          INTEGER NOT NULL REFERENCES vpn_nodes(id) ON DELETE CASCADE,
    panel_inbound_id INTEGER NOT NULL,
    position         INTEGER NOT NULL,
    protocol         TEXT,
    is_active        INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
    UNIQUE (node_id, panel_inbound_id),
    UNIQUE (node_id, position)
);

CREATE TABLE vpn_clients (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    inbound_id  INTEGER NOT NULL REFERENCES vpn_inbounds(id) ON DELETE CASCADE,
    email       TEXT NOT NULL UNIQUE,
    secret      TEXT NOT NULL,          -- uuid / password клиента в панели
    expiry_at   INTEGER NOT NULL,
    enabled     INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0,1)),
    synced_at   INTEGER NOT NULL,
    UNIQUE (user_id, inbound_id)
);

CREATE TABLE admin_logs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_tg_id  INTEGER NOT NULL,
    action       TEXT NOT NULL,
    target       TEXT,
    details      TEXT,
    created_at   INTEGER NOT NULL
);
CREATE INDEX idx_admin_logs_created ON admin_logs(created_at);

CREATE TABLE notifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind        TEXT NOT NULL,
    ref         TEXT NOT NULL,
    sent        INTEGER NOT NULL DEFAULT 0,
    created_at  INTEGER NOT NULL,
    UNIQUE (user_id, kind, ref)
);

CREATE TABLE settings (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
);
