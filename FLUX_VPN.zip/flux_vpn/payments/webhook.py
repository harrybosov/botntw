"""Необязательный HTTP-сервер для VPN subscription feed и legacy-интеграций."""
from __future__ import annotations

import hmac
import logging

from aiohttp import web

log = logging.getLogger(__name__)


def build_app(cryptobot=None, secret: str = "", vpn=None) -> web.Application:
    """HTTP-сервер: /sub/<token> (единая VPN-подписка); платежи cisPay здесь не обрабатываются."""
    async def crypto_hook(request: web.Request) -> web.Response:
        if not secret or not hmac.compare_digest(request.match_info["secret"], secret):
            return web.Response(status=404)
        raw = await request.read()
        status, msg = await cryptobot.handle_webhook(raw, request.headers.get("crypto-pay-api-signature", ""))
        return web.Response(status=status, text=msg)

    async def sub_feed(request: web.Request) -> web.Response:
        status, headers, body = await vpn.feed(request.match_info["token"])
        return web.Response(status=status, text=body, headers=headers, content_type="text/plain", charset="utf-8")

    async def health(_: web.Request) -> web.Response:
        return web.Response(text="ok")

    app = web.Application(client_max_size=256 * 1024)
    if cryptobot is not None and secret:
        app.router.add_post("/webhooks/cryptobot/{secret}", crypto_hook)
    if vpn is not None:
        app.router.add_get("/sub/{token}", sub_feed)
    app.router.add_get("/health", health)
    return app


async def start_server(app: web.Application, host: str, port: int) -> web.AppRunner:
    runner = web.AppRunner(app, access_log=None)
    await runner.setup()
    await web.TCPSite(runner, host, port).start()
    log.info("Webhook-сервер: http://%s:%s", host, port)
    return runner
