"""Telegram Stars (валюта XTR). Документация: Telegram Bot API — sendInvoice / pre_checkout_query /
successful_payment / refundStarPayment. Для Stars provider_token не нужен."""
from __future__ import annotations

import logging

from models import CURRENCY_STARS, OrderStatus, Provider
from payments.base import PaymentProvider, PaymentStart
from utils import clock

log = logging.getLogger(__name__)


class StarsProvider(PaymentProvider):
    code = Provider.STARS
    title = "⭐ Telegram Stars"

    def __init__(self, bot, plans, orders, users, fulfillment, enabled: bool = True):
        self.bot, self.plans, self.orders = bot, plans, orders
        self.users, self.fulfillment, self.enabled = users, fulfillment, enabled

    def is_configured(self) -> bool:
        return self.enabled

    async def available_for(self, plan_id: str) -> bool:
        return self.enabled and bool(await self.plans.stars_price(plan_id))

    async def start(self, order: dict, user: dict) -> PaymentStart:
        from aiogram.types import LabeledPrice
        await self.bot.send_invoice(
            chat_id=user["tg_id"],
            title=f"FLUX VPN — {order['plan_name']}"[:32],
            description=f"Подписка FLUX VPN на {order['days']} дн. (6 подключений: Германия и США)"[:255],
            payload=order["public_id"],
            currency=CURRENCY_STARS,
            prices=[LabeledPrice(label=order["plan_name"][:30], amount=order["amount"])],
        )
        return PaymentStart(text=f"⭐ Счёт на <b>{order['amount']} Stars</b> отправлен ниже. "
                                 "Оплатите его кнопкой «Pay» — доступ выдаётся сразу после подтверждения Telegram.")

    async def validate_pre_checkout(self, from_tg_id: int, payload: str, currency: str,
                                    total_amount: int) -> tuple[bool, str]:
        """Вызывается из pre_checkout_query (ответить нужно за 10 секунд)."""
        order = await self.orders.get_by_public(payload)
        if not order or order["provider"] != Provider.STARS:
            return False, "Заказ не найден. Создайте новый заказ в боте."
        user = await self.users.get(order["user_id"])
        if not user or user["tg_id"] != from_tg_id:
            return False, "Этот счёт выставлен другому пользователю."
        if user["is_blocked"]:
            return False, "Доступ к боту ограничен."
        if order["status"] != OrderStatus.PENDING or order["expires_at"] <= clock.now():
            return False, "Счёт устарел. Создайте новый заказ в боте."
        if currency != CURRENCY_STARS or total_amount != order["amount"]:
            return False, "Сумма счёта не совпадает с заказом."
        return True, ""

    async def handle_successful_payment(self, from_tg_id: int, sp) -> str:
        """sp — aiogram SuccessfulPayment. Возвращает статус обработки."""
        order = await self.orders.get_by_public(sp.invoice_payload)
        if not order:
            log.error("successful_payment для неизвестного заказа %s", sp.invoice_payload)
            await self.fulfillment.notifier.notify_admins(
                f"⚠️ Stars: оплата без заказа! payload={sp.invoice_payload} charge={sp.telegram_payment_charge_id}")
            return "not_found"
        user = await self.users.get(order["user_id"])
        if not user or user["tg_id"] != from_tg_id:
            log.error("successful_payment от чужого пользователя: order=%s", order["public_id"])
            return "rejected"
        out = await self.fulfillment.confirm(
            order["id"], source=Provider.STARS, external_id=sp.telegram_payment_charge_id,
            amount=sp.total_amount, currency=sp.currency,
            note=f"provider_charge={getattr(sp, 'provider_payment_charge_id', '')}")
        return out.status

    async def refund(self, order: dict) -> tuple[bool, str]:
        """Возврат Stars через Bot API refundStarPayment + откат срока подписки."""
        if order["provider"] != Provider.STARS or order["status"] != OrderStatus.PAID:
            return False, "Возврат возможен только для оплаченных заказов Stars"
        pay = await self.orders.payment_for_order(order["id"])
        if not pay or pay["provider"] != Provider.STARS:
            return False, "Платёж Stars для заказа не найден"
        user = await self.users.get(order["user_id"])
        try:
            await self.bot.refund_star_payment(user_id=user["tg_id"], telegram_payment_charge_id=pay["external_id"])
        except Exception as e:  # noqa: BLE001  (TelegramAPIError и др.)
            log.warning("refund_star_payment failed: %s", e)
            return False, f"Telegram отклонил возврат: {e}"
        await self.fulfillment.refund(order["id"])
        return True, "Возврат выполнен"
